/*! For license information please see crypo-mining-fleet-card.js.LICENSE.txt */
var A={d:(B,Q)=>{for(var t in Q)A.o(Q,t)&&!A.o(B,t)&&Object.defineProperty(B,t,{enumerable:!0,get:Q[t]})},o:(A,B)=>Object.prototype.hasOwnProperty.call(A,B)};(()=>{var B;if("string"==typeof import.meta.url&&(B=import.meta.url),!B)throw new Error("Automatic publicPath is not supported in this browser");B=B.replace(/^blob:/,"").replace(/#.*$/,"").replace(/\?.*$/,"").replace(/\/[^\/]+$/,"/"),A.p=B})();const B=globalThis,Q=B.ShadowRoot&&(void 0===B.ShadyCSS||B.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,t=Symbol(),e=new WeakMap;class E{constructor(A,B,Q){if(this._$cssResult$=!0,Q!==t)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=A,this.t=B}get styleSheet(){let A=this.o;const B=this.t;if(Q&&void 0===A){const Q=void 0!==B&&1===B.length;Q&&(A=e.get(B)),void 0===A&&((this.o=A=new CSSStyleSheet).replaceSync(this.cssText),Q&&e.set(B,A))}return A}toString(){return this.cssText}}const w=(A,...B)=>{const Q=1===A.length?A[0]:B.reduce((B,Q,t)=>B+(A=>{if(!0===A._$cssResult$)return A.cssText;if("number"==typeof A)return A;throw Error("Value passed to 'css' function must be a 'css' function result: "+A+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(Q)+A[t+1],A[0]);return new E(Q,A,t)},s=(A,t)=>{if(Q)A.adoptedStyleSheets=t.map(A=>A instanceof CSSStyleSheet?A:A.styleSheet);else for(const Q of t){const t=document.createElement("style"),e=B.litNonce;void 0!==e&&t.setAttribute("nonce",e),t.textContent=Q.cssText,A.appendChild(t)}},g=Q?A=>A:A=>A instanceof CSSStyleSheet?(A=>{let B="";for(const Q of A.cssRules)B+=Q.cssText;return(A=>new E("string"==typeof A?A:A+"",void 0,t))(B)})(A):A,{is:i,defineProperty:C,getOwnPropertyDescriptor:o,getOwnPropertyNames:n,getOwnPropertySymbols:D,getPrototypeOf:c}=Object,r=globalThis,h=r.trustedTypes,a=h?h.emptyScript:"",l=r.reactiveElementPolyfillSupport,I=(A,B)=>A,M={toAttribute(A,B){switch(B){case Boolean:A=A?a:null;break;case Object:case Array:A=null==A?A:JSON.stringify(A)}return A},fromAttribute(A,B){let Q=A;switch(B){case Boolean:Q=null!==A;break;case Number:Q=null===A?null:Number(A);break;case Object:case Array:try{Q=JSON.parse(A)}catch(A){Q=null}}return Q}},P=(A,B)=>!i(A,B),F={attribute:!0,type:String,converter:M,reflect:!1,useDefault:!1,hasChanged:P};Symbol.metadata??=Symbol("metadata"),r.litPropertyMetadata??=new WeakMap;class U extends HTMLElement{static addInitializer(A){this._$Ei(),(this.l??=[]).push(A)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(A,B=F){if(B.state&&(B.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(A)&&((B=Object.create(B)).wrapped=!0),this.elementProperties.set(A,B),!B.noAccessor){const Q=Symbol(),t=this.getPropertyDescriptor(A,Q,B);void 0!==t&&C(this.prototype,A,t)}}static getPropertyDescriptor(A,B,Q){const{get:t,set:e}=o(this.prototype,A)??{get(){return this[B]},set(A){this[B]=A}};return{get:t,set(B){const E=t?.call(this);e?.call(this,B),this.requestUpdate(A,E,Q)},configurable:!0,enumerable:!0}}static getPropertyOptions(A){return this.elementProperties.get(A)??F}static _$Ei(){if(this.hasOwnProperty(I("elementProperties")))return;const A=c(this);A.finalize(),void 0!==A.l&&(this.l=[...A.l]),this.elementProperties=new Map(A.elementProperties)}static finalize(){if(this.hasOwnProperty(I("finalized")))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(I("properties"))){const A=this.properties,B=[...n(A),...D(A)];for(const Q of B)this.createProperty(Q,A[Q])}const A=this[Symbol.metadata];if(null!==A){const B=litPropertyMetadata.get(A);if(void 0!==B)for(const[A,Q]of B)this.elementProperties.set(A,Q)}this._$Eh=new Map;for(const[A,B]of this.elementProperties){const Q=this._$Eu(A,B);void 0!==Q&&this._$Eh.set(Q,A)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(A){const B=[];if(Array.isArray(A)){const Q=new Set(A.flat(1/0).reverse());for(const A of Q)B.unshift(g(A))}else void 0!==A&&B.push(g(A));return B}static _$Eu(A,B){const Q=B.attribute;return!1===Q?void 0:"string"==typeof Q?Q:"string"==typeof A?A.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(A=>this.enableUpdating=A),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(A=>A(this))}addController(A){(this._$EO??=new Set).add(A),void 0!==this.renderRoot&&this.isConnected&&A.hostConnected?.()}removeController(A){this._$EO?.delete(A)}_$E_(){const A=new Map,B=this.constructor.elementProperties;for(const Q of B.keys())this.hasOwnProperty(Q)&&(A.set(Q,this[Q]),delete this[Q]);A.size>0&&(this._$Ep=A)}createRenderRoot(){const A=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return s(A,this.constructor.elementStyles),A}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(A=>A.hostConnected?.())}enableUpdating(A){}disconnectedCallback(){this._$EO?.forEach(A=>A.hostDisconnected?.())}attributeChangedCallback(A,B,Q){this._$AK(A,Q)}_$ET(A,B){const Q=this.constructor.elementProperties.get(A),t=this.constructor._$Eu(A,Q);if(void 0!==t&&!0===Q.reflect){const e=(void 0!==Q.converter?.toAttribute?Q.converter:M).toAttribute(B,Q.type);this._$Em=A,null==e?this.removeAttribute(t):this.setAttribute(t,e),this._$Em=null}}_$AK(A,B){const Q=this.constructor,t=Q._$Eh.get(A);if(void 0!==t&&this._$Em!==t){const A=Q.getPropertyOptions(t),e="function"==typeof A.converter?{fromAttribute:A.converter}:void 0!==A.converter?.fromAttribute?A.converter:M;this._$Em=t;const E=e.fromAttribute(B,A.type);this[t]=E??this._$Ej?.get(t)??E,this._$Em=null}}requestUpdate(A,B,Q,t=!1,e){if(void 0!==A){const E=this.constructor;if(!1===t&&(e=this[A]),Q??=E.getPropertyOptions(A),!((Q.hasChanged??P)(e,B)||Q.useDefault&&Q.reflect&&e===this._$Ej?.get(A)&&!this.hasAttribute(E._$Eu(A,Q))))return;this.C(A,B,Q)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(A,B,{useDefault:Q,reflect:t,wrapped:e},E){Q&&!(this._$Ej??=new Map).has(A)&&(this._$Ej.set(A,E??B??this[A]),!0!==e||void 0!==E)||(this._$AL.has(A)||(this.hasUpdated||Q||(B=void 0),this._$AL.set(A,B)),!0===t&&this._$Em!==A&&(this._$Eq??=new Set).add(A))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(A){Promise.reject(A)}const A=this.scheduleUpdate();return null!=A&&await A,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[A,B]of this._$Ep)this[A]=B;this._$Ep=void 0}const A=this.constructor.elementProperties;if(A.size>0)for(const[B,Q]of A){const{wrapped:A}=Q,t=this[B];!0!==A||this._$AL.has(B)||void 0===t||this.C(B,void 0,Q,t)}}let A=!1;const B=this._$AL;try{A=this.shouldUpdate(B),A?(this.willUpdate(B),this._$EO?.forEach(A=>A.hostUpdate?.()),this.update(B)):this._$EM()}catch(B){throw A=!1,this._$EM(),B}A&&this._$AE(B)}willUpdate(A){}_$AE(A){this._$EO?.forEach(A=>A.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(A)),this.updated(A)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(A){return!0}update(A){this._$Eq&&=this._$Eq.forEach(A=>this._$ET(A,this[A])),this._$EM()}updated(A){}firstUpdated(A){}}U.elementStyles=[],U.shadowRootOptions={mode:"open"},U[I("elementProperties")]=new Map,U[I("finalized")]=new Map,l?.({ReactiveElement:U}),(r.reactiveElementVersions??=[]).push("2.1.2");const u=globalThis,G=A=>A,L=u.trustedTypes,p=L?L.createPolicy("lit-html",{createHTML:A=>A}):void 0,k="$lit$",z=`lit$${Math.random().toFixed(9).slice(2)}$`,d="?"+z,S=`<${d}>`,Y=document,R=()=>Y.createComment(""),J=A=>null===A||"object"!=typeof A&&"function"!=typeof A,f=Array.isArray,T=A=>f(A)||"function"==typeof A?.[Symbol.iterator],v="[ \t\n\f\r]",H=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,y=/-->/g,x=/>/g,N=RegExp(`>|${v}(?:([^\\s"'>=/]+)(${v}*=${v}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),K=/'/g,W=/"/g,m=/^(?:script|style|textarea|title)$/i,O=A=>(B,...Q)=>({_$litType$:A,strings:B,values:Q}),j=O(1),b=(O(2),O(3),Symbol.for("lit-noChange")),_=Symbol.for("lit-nothing"),Z=new WeakMap,$=Y.createTreeWalker(Y,129);function V(A,B){if(!f(A)||!A.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==p?p.createHTML(B):B}const X=(A,B)=>{const Q=A.length-1,t=[];let e,E=2===B?"<svg>":3===B?"<math>":"",w=H;for(let B=0;B<Q;B++){const Q=A[B];let s,g,i=-1,C=0;for(;C<Q.length&&(w.lastIndex=C,g=w.exec(Q),null!==g);)C=w.lastIndex,w===H?"!--"===g[1]?w=y:void 0!==g[1]?w=x:void 0!==g[2]?(m.test(g[2])&&(e=RegExp("</"+g[2],"g")),w=N):void 0!==g[3]&&(w=N):w===N?">"===g[0]?(w=e??H,i=-1):void 0===g[1]?i=-2:(i=w.lastIndex-g[2].length,s=g[1],w=void 0===g[3]?N:'"'===g[3]?W:K):w===W||w===K?w=N:w===y||w===x?w=H:(w=N,e=void 0);const o=w===N&&A[B+1].startsWith("/>")?" ":"";E+=w===H?Q+S:i>=0?(t.push(s),Q.slice(0,i)+k+Q.slice(i)+z+o):Q+z+(-2===i?B:o)}return[V(A,E+(A[Q]||"<?>")+(2===B?"</svg>":3===B?"</math>":"")),t]};class q{constructor({strings:A,_$litType$:B},Q){let t;this.parts=[];let e=0,E=0;const w=A.length-1,s=this.parts,[g,i]=X(A,B);if(this.el=q.createElement(g,Q),$.currentNode=this.el.content,2===B||3===B){const A=this.el.content.firstChild;A.replaceWith(...A.childNodes)}for(;null!==(t=$.nextNode())&&s.length<w;){if(1===t.nodeType){if(t.hasAttributes())for(const A of t.getAttributeNames())if(A.endsWith(k)){const B=i[E++],Q=t.getAttribute(A).split(z),w=/([.?@])?(.*)/.exec(B);s.push({type:1,index:e,name:w[2],strings:Q,ctor:"."===w[1]?eA:"?"===w[1]?EA:"@"===w[1]?wA:tA}),t.removeAttribute(A)}else A.startsWith(z)&&(s.push({type:6,index:e}),t.removeAttribute(A));if(m.test(t.tagName)){const A=t.textContent.split(z),B=A.length-1;if(B>0){t.textContent=L?L.emptyScript:"";for(let Q=0;Q<B;Q++)t.append(A[Q],R()),$.nextNode(),s.push({type:2,index:++e});t.append(A[B],R())}}}else if(8===t.nodeType)if(t.data===d)s.push({type:2,index:e});else{let A=-1;for(;-1!==(A=t.data.indexOf(z,A+1));)s.push({type:7,index:e}),A+=z.length-1}e++}}static createElement(A,B){const Q=Y.createElement("template");return Q.innerHTML=A,Q}}function AA(A,B,Q=A,t){if(B===b)return B;let e=void 0!==t?Q._$Co?.[t]:Q._$Cl;const E=J(B)?void 0:B._$litDirective$;return e?.constructor!==E&&(e?._$AO?.(!1),void 0===E?e=void 0:(e=new E(A),e._$AT(A,Q,t)),void 0!==t?(Q._$Co??=[])[t]=e:Q._$Cl=e),void 0!==e&&(B=AA(A,e._$AS(A,B.values),e,t)),B}class BA{constructor(A,B){this._$AV=[],this._$AN=void 0,this._$AD=A,this._$AM=B}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(A){const{el:{content:B},parts:Q}=this._$AD,t=(A?.creationScope??Y).importNode(B,!0);$.currentNode=t;let e=$.nextNode(),E=0,w=0,s=Q[0];for(;void 0!==s;){if(E===s.index){let B;2===s.type?B=new QA(e,e.nextSibling,this,A):1===s.type?B=new s.ctor(e,s.name,s.strings,this,A):6===s.type&&(B=new sA(e,this,A)),this._$AV.push(B),s=Q[++w]}E!==s?.index&&(e=$.nextNode(),E++)}return $.currentNode=Y,t}p(A){let B=0;for(const Q of this._$AV)void 0!==Q&&(void 0!==Q.strings?(Q._$AI(A,Q,B),B+=Q.strings.length-2):Q._$AI(A[B])),B++}}class QA{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(A,B,Q,t){this.type=2,this._$AH=_,this._$AN=void 0,this._$AA=A,this._$AB=B,this._$AM=Q,this.options=t,this._$Cv=t?.isConnected??!0}get parentNode(){let A=this._$AA.parentNode;const B=this._$AM;return void 0!==B&&11===A?.nodeType&&(A=B.parentNode),A}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(A,B=this){A=AA(this,A,B),J(A)?A===_||null==A||""===A?(this._$AH!==_&&this._$AR(),this._$AH=_):A!==this._$AH&&A!==b&&this._(A):void 0!==A._$litType$?this.$(A):void 0!==A.nodeType?this.T(A):T(A)?this.k(A):this._(A)}O(A){return this._$AA.parentNode.insertBefore(A,this._$AB)}T(A){this._$AH!==A&&(this._$AR(),this._$AH=this.O(A))}_(A){this._$AH!==_&&J(this._$AH)?this._$AA.nextSibling.data=A:this.T(Y.createTextNode(A)),this._$AH=A}$(A){const{values:B,_$litType$:Q}=A,t="number"==typeof Q?this._$AC(A):(void 0===Q.el&&(Q.el=q.createElement(V(Q.h,Q.h[0]),this.options)),Q);if(this._$AH?._$AD===t)this._$AH.p(B);else{const A=new BA(t,this),Q=A.u(this.options);A.p(B),this.T(Q),this._$AH=A}}_$AC(A){let B=Z.get(A.strings);return void 0===B&&Z.set(A.strings,B=new q(A)),B}k(A){f(this._$AH)||(this._$AH=[],this._$AR());const B=this._$AH;let Q,t=0;for(const e of A)t===B.length?B.push(Q=new QA(this.O(R()),this.O(R()),this,this.options)):Q=B[t],Q._$AI(e),t++;t<B.length&&(this._$AR(Q&&Q._$AB.nextSibling,t),B.length=t)}_$AR(A=this._$AA.nextSibling,B){for(this._$AP?.(!1,!0,B);A!==this._$AB;){const B=G(A).nextSibling;G(A).remove(),A=B}}setConnected(A){void 0===this._$AM&&(this._$Cv=A,this._$AP?.(A))}}class tA{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(A,B,Q,t,e){this.type=1,this._$AH=_,this._$AN=void 0,this.element=A,this.name=B,this._$AM=t,this.options=e,Q.length>2||""!==Q[0]||""!==Q[1]?(this._$AH=Array(Q.length-1).fill(new String),this.strings=Q):this._$AH=_}_$AI(A,B=this,Q,t){const e=this.strings;let E=!1;if(void 0===e)A=AA(this,A,B,0),E=!J(A)||A!==this._$AH&&A!==b,E&&(this._$AH=A);else{const t=A;let w,s;for(A=e[0],w=0;w<e.length-1;w++)s=AA(this,t[Q+w],B,w),s===b&&(s=this._$AH[w]),E||=!J(s)||s!==this._$AH[w],s===_?A=_:A!==_&&(A+=(s??"")+e[w+1]),this._$AH[w]=s}E&&!t&&this.j(A)}j(A){A===_?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,A??"")}}class eA extends tA{constructor(){super(...arguments),this.type=3}j(A){this.element[this.name]=A===_?void 0:A}}class EA extends tA{constructor(){super(...arguments),this.type=4}j(A){this.element.toggleAttribute(this.name,!!A&&A!==_)}}class wA extends tA{constructor(A,B,Q,t,e){super(A,B,Q,t,e),this.type=5}_$AI(A,B=this){if((A=AA(this,A,B,0)??_)===b)return;const Q=this._$AH,t=A===_&&Q!==_||A.capture!==Q.capture||A.once!==Q.once||A.passive!==Q.passive,e=A!==_&&(Q===_||t);t&&this.element.removeEventListener(this.name,this,Q),e&&this.element.addEventListener(this.name,this,A),this._$AH=A}handleEvent(A){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,A):this._$AH.handleEvent(A)}}class sA{constructor(A,B,Q){this.element=A,this.type=6,this._$AN=void 0,this._$AM=B,this.options=Q}get _$AU(){return this._$AM._$AU}_$AI(A){AA(this,A)}}const gA=u.litHtmlPolyfillSupport;gA?.(q,QA),(u.litHtmlVersions??=[]).push("3.3.2");const iA=globalThis;class CA extends U{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const A=super.createRenderRoot();return this.renderOptions.renderBefore??=A.firstChild,A}update(A){const B=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(A),this._$Do=((A,B,Q)=>{const t=Q?.renderBefore??B;let e=t._$litPart$;if(void 0===e){const A=Q?.renderBefore??null;t._$litPart$=e=new QA(B.insertBefore(R(),A),A,void 0,Q??{})}return e._$AI(A),e})(B,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return b}}CA._$litElement$=!0,CA.finalized=!0,iA.litElementHydrateSupport?.({LitElement:CA});const oA=iA.litElementPolyfillSupport;oA?.({LitElement:CA});(iA.litElementVersions??=[]).push("4.2.2");const nA={attribute:!0,type:String,converter:M,reflect:!1,hasChanged:P},DA=(A=nA,B,Q)=>{const{kind:t,metadata:e}=Q;let E=globalThis.litPropertyMetadata.get(e);if(void 0===E&&globalThis.litPropertyMetadata.set(e,E=new Map),"setter"===t&&((A=Object.create(A)).wrapped=!0),E.set(Q.name,A),"accessor"===t){const{name:t}=Q;return{set(Q){const e=B.get.call(this);B.set.call(this,Q),this.requestUpdate(t,e,A,!0,Q)},init(B){return void 0!==B&&this.C(t,void 0,A,B),B}}}if("setter"===t){const{name:t}=Q;return function(Q){const e=this[t];B.call(this,Q),this.requestUpdate(t,e,A,!0,Q)}}throw Error("Unsupported decorator location: "+t)};const cA=A.p+"assets/baselayer.png";var rA=function(A,B,Q,t){var e,E=arguments.length,w=E<3?B:null===t?t=Object.getOwnPropertyDescriptor(B,Q):t;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)w=Reflect.decorate(A,B,Q,t);else for(var s=A.length-1;s>=0;s--)(e=A[s])&&(w=(E<3?e(w):E>3?e(B,Q,w):e(B,Q))||w);return E>3&&w&&Object.defineProperty(B,Q,w),w};if(!document.getElementById("crypto-miner-card-fonts")){const A=document.createElement("style");A.id="crypto-miner-card-fonts",A.textContent='\n    @font-face {\n      font-family: "AlienEncountersRegular";\n      src: url("data:font/ttf;base64,AAEAAAAQAEAABADAT1MvMlCBe/gAAES4AAAAVlBDTFRgT/LhAABFEAAAADZjbWFwMhA+sAAAN7gAAAXCY3Z0IGPlYhoAAATUAAAAKmZwZ22DM8JPAAAEwAAAABRnbHlmq2s6iAAABWQAAC7yaGRteAW9X3MAAD9wAAAFSGhlYWTJdtcpAABFSAAAADZoaGVhBzwDQAAARYAAAAAkaG10eLSCCJEAADWgAAABRGtlcm7w1PfFAAA9fAAAAfJsb2NhAAcuSAAANFgAAAFIbWF4cADbAT0AAEWkAAAAIG5hbWXlRGbhAAABDAAAA7Fwb3N0Z0BkhQAANuQAAADScHJlcJoTFEwAAAUAAAAAYQAAABgBJgAAAAAAAAAAAHoAPQAAAAAAAAABACwAzQAAAAAAAAACAA4BAAAAAAAAAAADAGQBggAAAAAAAAAEACwBJAAAAAAAAAAFAEYCCQAAAAAAAAAGACgCYwAAAAAAAAAHAAACiwABAAAAAAAAAD0AAAABAAAAAAABABYAtwABAAAAAAACAAcA+QABAAAAAAADADIBUAABAAAAAAAEABYBDgABAAAAAAAFACMB5gABAAAAAAAGABQCTwABAAAAAAAHAAACiwADAAEECQAAAHoAPQADAAEECQABACwAzQADAAEECQACAA4BAAADAAEECQADAGQBggADAAEECQAEACwBJAADAAEECQAFAEYCCQADAAEECQAGACgCYwADAAEECQAHAAACi3YxLjAgQ3JlYXRlZCBieSBTaHlXZWRnZSwgMTk5OS4gIChodHRwOi8vd2VsY29tZS50by9TaHlmb250cykAdgAxAC4AMAAgAEMAcgBlAGEAdABlAGQAIABiAHkAIABTAGgAeQBXAGUAZABnAGUALAAgADEAOQA5ADkALgAgACAAKABoAHQAdABwADoALwAvAHcAZQBsAGMAbwBtAGUALgB0AG8ALwBTAGgAeQBmAG8AbgB0AHMAKUFsaWVuIEVuY291bnRlcnMgU29saWQAQQBsAGkAZQBuACAARQBuAGMAbwB1AG4AdABlAHIAcwAgAFMAbwBsAGkAZFJlZ3VsYXIAUgBlAGcAdQBsAGEAckFsaWVuIEVuY291bnRlcnMgU29saWQAQQBsAGkAZQBuACAARQBuAGMAbwB1AG4AdABlAHIAcwAgAFMAbwBsAGkAZE1hY3JvbWVkaWEgRm9udG9ncmFwaGVyIDQuMSBBbGllbiBFbmNvdW50ZXJzIFNvbGlkAE0AYQBjAHIAbwBtAGUAZABpAGEAIABGAG8AbgB0AG8AZwByAGEAcABoAGUAcgAgADQALgAxACAAQQBsAGkAZQBuACAARQBuAGMAbwB1AG4AdABlAHIAcwAgAFMAbwBsAGkAZE1hY3JvbWVkaWEgRm9udG9ncmFwaGVyIDQuMSAzLzI4Lzk5AE0AYQBjAHIAbwBtAGUAZABpAGEAIABGAG8AbgB0AG8AZwByAGEAcABoAGUAcgAgADQALgAxACAAMwAvADIAOAAvADkAOUFsaWVuRW5jb3VudGVyc1NvbGlkAEEAbABpAGUAbgBFAG4AYwBvAHUAbgB0AGUAcgBzAFMAbwBsAGkAZAAAAEABACx2RSCwAyVFI2FoGCNoYEQt/zj/9gLBASoAyACLAGMAowB0AEAAyAGuAfQBhgFeAfQBzFpiWmIAAgAEAABAGxAQDw8ODg0NDAwLCwoKCQkICAcHAgIBAQAAAY24Af+FRWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhERWhEswQDRgArswYFRgArsQMDRWhEsQUFRWhEAAAAAAIAPwAAAbYDIAADAAcAVkAgAQgIQAkCBwQEAQAGBQQDAgUEBgAHBgYBAgEDAAEBAEZ2LzcYAD88LzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAAACEloYbBAUlg4ETe5AAj/wDhZMxEhESUzESM/AXf+x/r6AyD84D8CowACAB4AAAC0ArwAAwAHAFNAIAEICEAJAAEABwQDAwAEBgUCAwEHBgUEBQQBAwICAQFGdi83GAA/PD88EP08AS8XPP0XPAAuLjEwAUlouQABAAhJaGGwQFJYOBE3uQAI/8A4WTcjETMRIzUztJaWlpbwAcz9RIwAAgAeAeABcgK8AAUACwBpQC0BDAxADQACAQQACAcEBgQDBAUACwYECgkJCAMDAgUEBwYBAwALCgUDBAIBCUZ2LzcYAD8XPC8XPBD9FzwBLzz9PC88/TwQ/TwQ/TwAMTABSWi5AAkADEloYbBAUlg4ETe5AAz/wDhZASM1IzUzByM1IzUzAXJLS5a+S0uWAeBQjNxQjAAAAQAeAeAAtAK8AAUATUAbAQYGQAcAAgEEAAUABAQDAwIFBAEABQQCAQNGdi83GAA/PC88EP08AS88/TwQ/TwAMTABSWi5AAMABkloYbBAUlg4ETe5AAb/wDhZEyM1IzUztEtLlgHgUIwAAAEAHv+wALQAjAAFAEpAGQEGBkAHAAIBBAAFAAQEAwUEAQADAgEBA0Z2LzcYAD88LzwvPAEvPP08EP08ADEwAUlouQADAAZJaGGwQFJYOBE3uQAG/8A4WRcjNSM1M7RLS5ZQUIwAAAEAHgAAALQAjAADAD9AEwEEBEAFAAMABAIBAwIBAAEBAUZ2LzcYAD88LzwBLzz9PAAxMAFJaLkAAQAESWhhsEBSWDgRN7kABP/AOFkzIzUztJaWjAAAAgAeAAACRAK8AA8AEwBXQCEBFBRAFQATEgQIBxEQBA8AExAFAxIRBQsMCwIEAwEBB0Z2LzcYAD88PzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAcAFEloYbBAUlg4ETe5ABT/wDhZJRQGIyEiJjURNDYzITIWFQMRIxECRDsp/qIpOzspAV4pO5b6ZCk7OykB9Ck7Oyn+NAGk/lwAAQAeAAABGAK8AAUATkAcAQYGQAcABAMDAAIBBAUAAwIFBAUEAgEAAQEDRnYvNxgAPzw/PBD9PAEvPP08EP08ADEwAUlouQADAAZJaGGwQFJYOBE3uQAG/8A4WSEjESM1MwEYlmT6AjCMAAEAHgAAAkQCvAAUAGhALAEVFUAWABMSBAkIAgMBBwYEFA4NAwAUEwUACAcFCRIRBQYFCgkCAQABAQFGdi83GAA/PD88Lzz9PBD9PBD9PAEvFzz9PC8XPP08ADEwAUlouQABABVJaGGwQFJYOBE3uQAV/8A4WSkBETQ2MyE1ITUhMhYdARQGIyEVIQJE/do7KQEs/nABwik7Oyn+1AGQAWgpO2SMOym0KTu0AAABAB4AAAJEArwAGABtQC4BGRlAGgAVDQwJCAUECwoHAwYEGBIRAwAGBQUDCAcFCgkMCwUNDg0CBAMBAQRGdi83GAA/PD88EP08Lzz9PBD9PAEvFzz9FzwuLi4uLi4uADEwAUlouQAEABlJaGGwQFJYOBE3uQAZ/8A4WSUUBiMhNSE1IzUzNSE1ITIWHQEUBiMyFhUCRDsp/j4BkMjI/nABwik7OykpO2QpO4y0jGSMOyluKTs7KQAAAQAeAAACRAK8AA0AakAvAQ4OQA8ADQAKCQQDAwQMCwIDAQgHBAYFBQQBAwAFDQwJAwgLCgcDBgIDAgEBBUZ2LzcYAD88Pxc8Lxc8/Rc8AS88/TwvFzz9FzwuLgAxMAFJaLkABQAOSWhhsEBSWDgRN7kADv/AOFkBIxEjESERMxUzNTMVMwJEMpb+opbIljIBQP7AAUABfPDw8AAAAQAeAAACRAK8ABQAaEAsARUVQBYABwYEFA4NAwAQDwQMCwUDBAYFBQMIBwUREA8OBQwNDAIEAwEBBEZ2LzcYAD88PzwQ/TwvPP08EP08AS8XPP08Lxc8/TwAMTABSWi5AAQAFUloYbBAUlg4ETe5ABX/wDhZJRQGIyE1ITUhIiY1ESEVIRUhMhYVAkQ7Kf4+AZD+1Ck7Aib+cAEsKTtkKTuMtDspARiMZDspAAIAHgAAAkQCvAATABcAaEArARgYQBkADQwXFg8DDgQIBxUUBBMAFxQFAw4NBQsWFQUQDwwLAgQDAQEHRnYvNxgAPzw/PC88/TwQ/TwQ/TwBLzz9PC88/Rc8Li4AMTABSWi5AAcAGEloYbBAUlg4ETe5ABj/wDhZJRQGIyEiJjURNDYzIRUhFSEyFhUHNSMVAkQ7Kf6iKTs7KQGQ/qIBLCk7lvpkKTs7KQH0KTuMZDsp3LS0AAEAHgAAAkQCvAAIAEtAGgEJCUAKAAQDAgEECAADAgUEBQQCAQABAQNGdi83GAA/PD88EP08AS88/TwuLgAxMAFJaLkAAwAJSWhhsEBSWDgRN7kACf/AOFkhIxEhNSEyFhUCRJb+cAHCKTsCMIw7KQADAB4AAAJEArwAHQAhACUAdEA0ASYmQCcAGgslJCEDIAQPDggDByMiHwMeBB0XFgMAJSIFAyAfBRIkIwUhHhMSAgQDAQEHRnYvNxgAPzw/PC88/TwQ/TwQ/TwBLxc8/Rc8Lxc8/Rc8Li4AMTABSWi5AAcAJkloYbBAUlg4ETe5ACb/wDhZJRQGIyEiJj0BNDYzIiY9ATQ2MyEyFh0BFAYjMhYVJzUjFRM1IxUCRDsp/qIpOzspKTs7KQFeKTs7KSk7lvr6+mQpOzspvik7OyluKTs7KW4pOzspqmRk/sC0tAAAAgAeAAACRAK8ABMAFwBoQCsBGBhAGQAFBBUUBwMGBBMAFxYEDAsGBQUDFxQFCAcWFQUPEA8CBAMBAQtGdi83GAA/PD88EP08Lzz9PBD9PAEvPP08Lzz9FzwuLgAxMAFJaLkACwAYSWhhsEBSWDgRN7kAGP/AOFklFAYjITUhNSEiJjURNDYzITIWFQc1IxUCRDsp/nABXv7UKTs7KQFeKTuW+mQpO4xkOykBBCk7OynctLQAAgAeAAAAtAHMAAMABwBVQCEBCAhACQAHBAMDAAQGBQIDAQEABQIHBgUEAwIFBAEBAUZ2LzcYAD88LzwQ/TwQ/TwBLxc8/Rc8ADEwAUlouQABAAhJaGGwQFJYOBE3uQAI/8A4WRMjNTMRIzUztJaWlpYBQIz+NIwAAgAe/7AAtAHMAAMACQBgQCcBCgpACwAGBQQACQQDAwAECAcCAwEBAAUCCQgFBgMCBQQHBgEBAUZ2LzcYAD88LzwvPBD9PBD9PAEvFzz9FzwQ/TwAMTABSWi5AAEACkloYbBAUlg4ETe5AAr/wDhZEyM1MxEjNSM1M7SWlktLlgFAjP3kUIwAAAIAHgAAAeACvAASABYAcUAyARcXQBgAFhMFAwQEFRQODQcFBgwLBBIABgUFCgQDBQsKDQwFDhYVBRMUEwEPDgIBBkZ2LzcYAD88PzwQ/TwQ/TwvPP08EP08AS88/TwvFzz9FzwAMTABSWi5AAYAF0loYbBAUlg4ETe5ABf/wDhZARQGKwEVIzU0NjsBNSE1ITIWFQEjNTMB4DspyJY7Kcj+1AFeKTv+1JaWAaQpO1B4KTtkjDsp/aiMAAIAAAAAAu4CvAAHAAoAjUBCAQsLQAwACQoIBQAKCggDAgMJCAkEBwQFBgYHBQUGCAoIAgIDAQABCQcJCgAAAQcHAAoIBQMCBwYCBQQBAwABAQVGdi83GAA/Fzw/PC88/TwBhy4IxAj8CMQIxAjEhy4IxAj8CMQIxAjEAS4uLi4ALjEwAUlouQAFAAtJaGGwQFJYOBE3uQAL/8A4WSEjJyEHIwEzAycHAu6qQP7mQKoBGL4KVVWgoAK8/nDV1QADAB4AAAJ2ArwAEAAUABgAbkAwARkZQBoADRgXFAMTBAUEFhUSAxEEEAoJAwAYFQUDExIFBRcWBRQRBgUCBAMBAQRGdi83GAA/PD88Lzz9PBD9PBD9PAEvFzz9FzwvPP0XPC4AMTABSWi5AAQAGUloYbBAUlg4ETe5ABn/wDhZJRQGIyERITIWHQEUBiMyFhUnNSEVATUhFQJ2Oyn+DAH0KTs7KSk7lv7UASz+1GQpOwK8OyluKTs7KapkZP7AtLQAAAEAHgAAAkQCvAANAFZAIAEODkAPAA0KCQAMCwQFBA0MBQALCgUICQgCAQABAQRGdi83GAA/PD88EP08EP08AS88/TwuLi4uADEwAUlouQAEAA5JaGGwQFJYOBE3uQAO/8A4WSkBIiY1ETQ2MyEVIREhAkT+Pik7OykBwv5wAZA7KQH0KTuM/lwAAAIAHgAAAnYCvAAJAA0AV0AhAQ4OQA8ADQwEBQQLCgQJAA0KBQMMCwUFBgUCBAMBAQRGdi83GAA/PD88EP08EP08AS88/TwvPP08ADEwAUlouQAEAA5JaGGwQFJYOBE3uQAO/8A4WSUUBiMhESEyFhUDESERAnY7Kf4MAfQpO5b+1GQpOwK8Oyn+NAGk/lwAAAEAHgAAAkQCvAARAGdAKgESEkATABEODQoJABAPDAMLBAUEERAFAAsKBQgPDgUNDAkIAgEAAQEERnYvNxgAPzw/PC88/TwQ/TwQ/TwBLzz9FzwuLi4uLi4AMTABSWi5AAQAEkloYbBAUlg4ETe5ABL/wDhZKQEiJjURNDYzIRUhFSEVIRUhAkT+Pik7OykBwv5wAZD+cAGQOykB9Ck7jGSMtAAAAQAeAAACRAK8AAwAXEAkAQ0NQA4ADAkIAAsKAgMBBAQDAQAFDAsKCQUHCAcCAwIBAQNGdi83GAA/PD88EP08Lzz9PAEvPP0XPC4uLi4AMTABSWi5AAMADUloYbBAUlg4ETe5AA3/wDhZASERIxE0NjMhFSEVIQJE/nCWOykBwv5wAZABQP7AAlgpO4xkAAEAHgAAAnYCvAARAGhAKwESEkATABAPDAsEBQQODQQRCgkDAA0MBQALCgUIDw4FERAJCAIBAAEBBEZ2LzcYAD88PzwvPP08EP08EP08AS8XPP08Lzz9PC4uADEwAUlouQAEABJJaGGwQFJYOBE3uQAS/8A4WSkBIiY1ETQ2MyEVIREhNSM1IQJ2/gwpOzspAfT+PgEsyAFeOykB9Ck7jP5ctIwAAQAeAAACdgK8AAsAYkAqAQwMQA0ACgkCAwEECwAIBwQDAwQGBQMCBQkICwoHAwYCBQQBAwABAQVGdi83GAA/Fzw/FzwvPP08AS88/Rc8Lzz9FzwAMTABSWi5AAUADEloYbBAUlg4ETe5AAz/wDhZISMRIREjETMVITUzAnaW/tSWlgEslgFA/sACvPDwAAEAHgAAALQCvAADAEBAFAEEBEAFAAMABAIBAwICAQABAQFGdi83GAA/PD88AS88/TwAMTABSWi5AAEABEloYbBAUlg4ETe5AAT/wDhZMyMRM7SWlgK8AAABAB4AAAJ2ArwADQBXQCEBDg5ADwAKCQQIBwwLBA0ACQgFAwsKBQMNDAIEAwEBB0Z2LzcYAD88PzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAcADkloYbBAUlg4ETe5AA7/wDhZJRQGIyEiJj0BMxUhETMCdjsp/nApO5YBLJZkKTs7KcigAjAAAQAeAAACsgK8AAoAiUBAAQsLQAwABwIKCQcACgoAAgECCQgJAwcDBAgICQcHCAoJCgAHAAECAgMBAQIGAwQFBAkIBgMFAgQDAQMAAQEERnYvNxgAPxc8Pxc8AS88/TyHLgjECPwIxIcuCMQI/AjECMQIxAEuLi4uAC4uMTABSWi5AAQAC0loYbBAUlg4ETe5AAv/wDhZISMnByMRMxEBMwMCsr6goJaWAUC+/9zcArz+SQG3/qIAAAEAHgAAAkQCvAAIAEtAGgEJCUAKAAgABwYEBQQIBwUABgUCAQABAQRGdi83GAA/PD88EP08AS88/TwuLgAxMAFJaLkABAAJSWhhsEBSWDgRN7kACf/AOFkpASImNREzESECRP4+KTuWAZA7KQJY/dAAAAEAHgAAAxYCvAAMAIZAPwENDUAOAAoFAgoJCgsHCwwDAwQCAgMJCAkKBwoLBQUGBAQFCwIBBAwABgUECAcMCwkDCAIHBgQDAQUAAQEHRnYvNxgAPxc8Pxc8AS88/TwvPP08PIcuCMQI/AjEhy4IxAj8CMQBAC4uLjEwAUlouQAHAA1JaGGwQFJYOBE3uQAN/8A4WSEjEQMjAxEjETMbATMDFpaqeKqWluTolgFe/qIBXv6iArz+JQHbAAEAHgAAAnYCvAAJAG1ALwEKCkALAAcCBwYFBgcHBwgCAgMBAQIDAgQFBAgBBAkACQgGAwUCBAMBAwABAQRGdi83GAA/Fzw/FzwBLzz9PC88/TyHLgjECPwIxAEuAC4uMTABSWi5AAQACkloYbBAUlg4ETe5AAr/wDhZISMBESMRMwERMwJ2lv7UlpYBLJYBpP5cArz+XAGkAAACAB4AAAJ2ArwADwATAFdAIQEUFEAVABMSBAgHERAEDwATEAUDEhEFCwwLAgQDAQEHRnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABwAUSWhhsEBSWDgRN7kAFP/AOFklFAYjISImNRE0NjMhMhYVAxEhEQJ2Oyn+cCk7OykBkCk7lv7UZCk7OykB9Ck7Oyn+NAGk/lwAAAIAHgAAAnYCvAALAA8AXUAlARAQQBEADw4FAwQEBwYNDAQLAAQDBQ8MDg0FBwgHAgYFAQEGRnYvNxgAPzw/PBD9PC88/TwBLzz9PC88/Rc8ADEwAUlouQAGABBJaGGwQFJYOBE3uQAQ/8A4WQEUBiMhESMRITIWFQc1IRUCdjsp/qKWAfQpO5b+1AGkKTv+wAK8OymMZGQAAgAeAAAC2gK8AA4AEgBfQCYBExNAFAAOABIRBAUEEA8EDQwSDw4DDQUAERAFCAkIAgEAAQEERnYvNxgAPzw/PBD9PBD9FzwBLzz9PC88/TwuLgAxMAFJaLkABAATSWhhsEBSWDgRN7kAE//AOFkpASImNRE0NjMhMhYVETMjESERAtr9qCk7OykBkCk7ZPr+1DspAfQpOzsp/jQBpP5cAAIAHgAAAnYCvAARABUAa0AvARYWQBcADhMSAgMBBBELCgMAFRQEAwMEBgUDAgUVEhQTBQYHBgIFBAEDAAEBBUZ2LzcYAD8XPD88EP08Lzz9PAEvPP0XPC8XPP0XPC4AMTABSWi5AAUAFkloYbBAUlg4ETe5ABb/wDhZISMRIREjESEyFh0BFAYjMhYVJzUhFQJ2lv7UlgH0KTs7KSk7lv7UAUD+wAK8OyluKTs7KapkZAABAB4AAAJ2ArwAFwBoQCwBGBhAGQAHBgQXERADABMSBAwLBQMEBgUFAwgHBRQTEhEFDxAPAgQDAQEERnYvNxgAPzw/PBD9PC88/TwQ/TwBLxc8/TwvFzz9PAAxMAFJaLkABAAYSWhhsEBSWDgRN7kAGP/AOFklFAYjITUhNSEiJj0BNDYzIRUhFSEyFhUCdjsp/gwBwv6iKTs7KQH0/j4BXik7ZCk7jLQ7KbQpO4xkOykAAQAeAAACdgK8AAcAU0AfAQgIQAkABwYFAAQDBAIBBQQBAwAFBgcGAgMCAQEFRnYvNxgAPzw/PBD9FzwBLzz9PC4uLi4AMTABSWi5AAUACEloYbBAUlg4ETe5AAj/wDhZASMRIxEjNSECdteW6wJYAjD90AIwjAAAAQAeAAACdgK8AA0AVEAgAQ4OQA8ACgkECAcMCwQNAAsKBQMNDAkDCAIEAwEBB0Z2LzcYAD88Pxc8EP08AS88/TwvPP08ADEwAUlouQAHAA5JaGGwQFJYOBE3uQAO/8A4WSUUBiMhIiY1ETMRIREzAnY7Kf5wKTuWASyWZCk7OykCWP3QAjAAAAEAAAAAAu4CvAAGAGxALwEHB0AIAAUDAAUEBQYHBgABAQIAAAEEAwQFBwUGAwMEAgIDAgEBBgQDAwACAQNGdi83GAA/Fzw/PAGHLgjECPwIxIcuCMQI/AjEAS4uAC4xMAFJaLkAAwAHSWhhsEBSWDgRN7kAB//AOFkJASMBMxsBAu7+6L7+6KrNzQK8/UQCvP3/AgEAAAEAAAAABBoCvAARANRAbwESEkATABAMCAMPDgoJBgAMCwwJCQoIBwgNBw0ODw8QAwIDBAQFDg4EEA8QEQcRAAEBAgAAAQcGBwgHCAkGBgcFBQYPDg8MDA0LCgsQBxARCQgJAwMECgoLAgIKBQQCAwEBEQ4NCwoHBgcAAgEGRnYvNxgAPxc8Pxc8AYcuCMQIxAjECPwIxAjECMSHLgjECPwIxIcuCMQI/AjEhy4IxAjECMQI/AjECMQIxAEuLi4uLi4ALi4uLjEwAUlouQAGABJJaGGwQFJYOBE3uQAS/8A4WQkBIycHIwEzEzcDMxc3MwMXEwQa/ui+Nze+/uiqzUGMqjc3qoxBzQK8/USKigK8/f+jAV6Jif6iowIBAAABAB4AAALaArwACwCiQE8BDAxADQAIAgsKBgUEAAgHCAUFBgQDBAkHCQoLCwACAQIDAwQKCgMLCgsICAkHBgcABwABBQQFAgIDBgYHAQEGCgkHAwYCBAMBAwABAQRGdi83GAA/Fzw/FzwBhy4IxAjECMQI/AjECMQIxIcuCMQIxAjECPwIxAjECMQBLi4uLi4uAC4uMTABSWi5AAQADEloYbBAUlg4ETe5AAz/wDhZISMnByMTAzMXNzMDAtq+oKC+//++oKC+/9vbAV4BXtzc/qIAAAEAHgAAAtoCvAAIAHVANAEJCUAKAAcFAAcGBwgHCAABAQIAAAEGBQYHBwcIBQUGBAQFAgEEBAMDAgEIBgUDAAIBBUZ2LzcYAD8XPD88AS88/TyHLgjECPwIxIcuCMQI/AjEAS4uAC4xMAFJaLkABQAJSWhhsEBSWDgRN7kACf/AOFkJAREjEQEzFzcC2v7tlv7tvqCgArz+hP7AAUABfNzcAAEAHgAAAnYCvAAJAHFALwEKCkALAAgJCAcGBQQDAgEAAgECAwcDBAgICQcHCAkCBQAEAwUFBgUCAQABAQFGdi83GAA/PD88EP08EP08AYcuCMQI/AjEAS4uLi4uLi4uLi4ALjEwAUlouQABAApJaGGwQFJYOBE3uQAK/8A4WSkBNQEhNSEVASECdv2oAX7+ggJY/oIBfowBpIyM/lwAAgAAAAAC7gK8AAcACgCNQEIBCwtADAAJCggFAAoKCAMCAwkICQQHBAUGBgcFBQYICggCAgMBAAEJBwkKAAABBwcACggFAwIHBgIFBAEDAAEBBUZ2LzcYAD8XPD88Lzz9PAGHLgjECPwIxAjECMSHLgjECPwIxAjECMQBLi4uLgAuMTABSWi5AAUAC0loYbBAUlg4ETe5AAv/wDhZISMnIQcjATMDJwcC7qpA/uZAqgEYvgpVVaCgArz+cNXVAAMAHgAAAnYCvAAQABQAGABuQDABGRlAGgANGBcUAxMEBQQWFRIDEQQQCgkDABgVBQMTEgUFFxYFFBEGBQIEAwEBBEZ2LzcYAD88PzwvPP08EP08EP08AS8XPP0XPC88/Rc8LgAxMAFJaLkABAAZSWhhsEBSWDgRN7kAGf/AOFklFAYjIREhMhYdARQGIzIWFSc1IRUBNSEVAnY7Kf4MAfQpOzspKTuW/tQBLP7UZCk7Arw7KW4pOzspqmRk/sC0tAAAAQAeAAACRAK8AA0AVkAgAQ4OQA8ADQoJAAwLBAUEDQwFAAsKBQgJCAIBAAEBBEZ2LzcYAD88PzwQ/TwQ/TwBLzz9PC4uLi4AMTABSWi5AAQADkloYbBAUlg4ETe5AA7/wDhZKQEiJjURNDYzIRUhESECRP4+KTs7KQHC/nABkDspAfQpO4z+XAAAAgAeAAACdgK8AAkADQBXQCEBDg5ADwANDAQFBAsKBAkADQoFAwwLBQUGBQIEAwEBBEZ2LzcYAD88PzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAQADkloYbBAUlg4ETe5AA7/wDhZJRQGIyERITIWFQMRIRECdjsp/gwB9Ck7lv7UZCk7Arw7Kf40AaT+XAAAAQAeAAACRAK8ABEAZ0AqARISQBMAEQ4NCgkAEA8MAwsEBQQREAUACwoFCA8OBQ0MCQgCAQABAQRGdi83GAA/PD88Lzz9PBD9PBD9PAEvPP0XPC4uLi4uLgAxMAFJaLkABAASSWhhsEBSWDgRN7kAEv/AOFkpASImNRE0NjMhFSEVIRUhFSECRP4+KTs7KQHC/nABkP5wAZA7KQH0KTuMZIy0AAABAB4AAAJEArwADABcQCQBDQ1ADgAMCQgACwoCAwEEBAMBAAUMCwoJBQcIBwIDAgEBA0Z2LzcYAD88PzwQ/TwvPP08AS88/Rc8Li4uLgAxMAFJaLkAAwANSWhhsEBSWDgRN7kADf/AOFkBIREjETQ2MyEVIRUhAkT+cJY7KQHC/nABkAFA/sACWCk7jGQAAQAeAAACdgK8ABEAaEArARISQBMAEA8MCwQFBA4NBBEKCQMADQwFAAsKBQgPDgUREAkIAgEAAQEERnYvNxgAPzw/PC88/TwQ/TwQ/TwBLxc8/TwvPP08Li4AMTABSWi5AAQAEkloYbBAUlg4ETe5ABL/wDhZKQEiJjURNDYzIRUhESE1IzUhAnb+DCk7OykB9P4+ASzIAV47KQH0KTuM/ly0jAABAB4AAAJ2ArwACwBiQCoBDAxADQAKCQIDAQQLAAgHBAMDBAYFAwIFCQgLCgcDBgIFBAEDAAEBBUZ2LzcYAD8XPD8XPC88/TwBLzz9FzwvPP0XPAAxMAFJaLkABQAMSWhhsEBSWDgRN7kADP/AOFkhIxEhESMRMxUhNTMCdpb+1JaWASyWAUD+wAK88PAAAQAeAAAAtAK8AAMAQEAUAQQEQAUAAwAEAgEDAgIBAAEBAUZ2LzcYAD88PzwBLzz9PAAxMAFJaLkAAQAESWhhsEBSWDgRN7kABP/AOFkzIxEztJaWArwAAAEAHgAAAnYCvAANAFdAIQEODkAPAAoJBAgHDAsEDQAJCAUDCwoFAw0MAgQDAQEHRnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABwAOSWhhsEBSWDgRN7kADv/AOFklFAYjISImPQEzFSERMwJ2Oyn+cCk7lgEslmQpOzspyKACMAABAB4AAAKyArwACgCJQEABCwtADAAHAgoJBwAKCgACAQIJCAkDBwMECAgJBwcICgkKAAcAAQICAwEBAgYDBAUECQgGAwUCBAMBAwABAQRGdi83GAA/Fzw/FzwBLzz9PIcuCMQI/AjEhy4IxAj8CMQIxAjEAS4uLi4ALi4xMAFJaLkABAALSWhhsEBSWDgRN7kAC//AOFkhIycHIxEzEQEzAwKyvqCglpYBQL7/3NwCvP5JAbf+ogAAAQAeAAACRAK8AAgAS0AaAQkJQAoACAAHBgQFBAgHBQAGBQIBAAEBBEZ2LzcYAD88PzwQ/TwBLzz9PC4uADEwAUlouQAEAAlJaGGwQFJYOBE3uQAJ/8A4WSkBIiY1ETMRIQJE/j4pO5YBkDspAlj90AAAAQAeAAADFgK8AAwAhkA/AQ0NQA4ACgUCCgkKCwcLDAMDBAICAwkICQoHCgsFBQYEBAULAgEEDAAGBQQIBwwLCQMIAgcGBAMBBQABAQdGdi83GAA/Fzw/FzwBLzz9PC88/Tw8hy4IxAj8CMSHLgjECPwIxAEALi4uMTABSWi5AAcADUloYbBAUlg4ETe5AA3/wDhZISMRAyMDESMRMxsBMwMWlqp4qpaW5OiWAV7+ogFe/qICvP4lAdsAAQAeAAACdgK8AAkAbUAvAQoKQAsABwIHBgUGBwcHCAICAwEBAgMCBAUECAEECQAJCAYDBQIEAwEDAAEBBEZ2LzcYAD8XPD8XPAEvPP08Lzz9PIcuCMQI/AjEAS4ALi4xMAFJaLkABAAKSWhhsEBSWDgRN7kACv/AOFkhIwERIxEzAREzAnaW/tSWlgEslgGk/lwCvP5cAaQAAAIAHgAAAnYCvAAPABMAV0AhARQUQBUAExIECAcREAQPABMQBQMSEQULDAsCBAMBAQdGdi83GAA/PD88EP08EP08AS88/TwvPP08ADEwAUlouQAHABRJaGGwQFJYOBE3uQAU/8A4WSUUBiMhIiY1ETQ2MyEyFhUDESERAnY7Kf5wKTs7KQGQKTuW/tRkKTs7KQH0KTs7Kf40AaT+XAAAAgAeAAACdgK8AAsADwBdQCUBEBBAEQAPDgUDBAQHBg0MBAsABAMFDwwODQUHCAcCBgUBAQZGdi83GAA/PD88EP08Lzz9PAEvPP08Lzz9FzwAMTABSWi5AAYAEEloYbBAUlg4ETe5ABD/wDhZARQGIyERIxEhMhYVBzUhFQJ2Oyn+opYB9Ck7lv7UAaQpO/7AArw7KYxkZAACAB4AAALaArwADgASAF9AJgETE0AUAA4AEhEEBQQQDwQNDBIPDgMNBQAREAUICQgCAQABAQRGdi83GAA/PD88EP08EP0XPAEvPP08Lzz9PC4uADEwAUlouQAEABNJaGGwQFJYOBE3uQAT/8A4WSkBIiY1ETQ2MyEyFhURMyMRIREC2v2oKTs7KQGQKTtk+v7UOykB9Ck7Oyn+NAGk/lwAAgAeAAACdgK8ABEAFQBrQC8BFhZAFwAOExICAwEEEQsKAwAVFAQDAwQGBQMCBRUSFBMFBgcGAgUEAQMAAQEFRnYvNxgAPxc8PzwQ/TwvPP08AS88/Rc8Lxc8/Rc8LgAxMAFJaLkABQAWSWhhsEBSWDgRN7kAFv/AOFkhIxEhESMRITIWHQEUBiMyFhUnNSEVAnaW/tSWAfQpOzspKTuW/tQBQP7AArw7KW4pOzspqmRkAAEAHgAAAnYCvAAXAGhALAEYGEAZAAcGBBcREAMAExIEDAsFAwQGBQUDCAcFFBMSEQUPEA8CBAMBAQRGdi83GAA/PD88EP08Lzz9PBD9PAEvFzz9PC8XPP08ADEwAUlouQAEABhJaGGwQFJYOBE3uQAY/8A4WSUUBiMhNSE1ISImPQE0NjMhFSEVITIWFQJ2Oyn+DAHC/qIpOzspAfT+PgFeKTtkKTuMtDsptCk7jGQ7KQABAB4AAAJ2ArwABwBTQB8BCAhACQAHBgUABAMEAgEFBAEDAAUGBwYCAwIBAQVGdi83GAA/PD88EP0XPAEvPP08Li4uLgAxMAFJaLkABQAISWhhsEBSWDgRN7kACP/AOFkBIxEjESM1IQJ215brAlgCMP3QAjCMAAABAB4AAAJ2ArwADQBUQCABDg5ADwAKCQQIBwwLBA0ACwoFAw0MCQMIAgQDAQEHRnYvNxgAPzw/FzwQ/TwBLzz9PC88/TwAMTABSWi5AAcADkloYbBAUlg4ETe5AA7/wDhZJRQGIyEiJjURMxEhETMCdjsp/nApO5YBLJZkKTs7KQJY/dACMAAAAQAAAAAC7gK8AAYAbEAvAQcHQAgABQMABQQFBgcGAAEBAgAAAQQDBAUHBQYDAwQCAgMCAQEGBAMDAAIBA0Z2LzcYAD8XPD88AYcuCMQI/AjEhy4IxAj8CMQBLi4ALjEwAUlouQADAAdJaGGwQFJYOBE3uQAH/8A4WQkBIwEzGwEC7v7ovv7oqs3NArz9RAK8/f8CAQAAAQAAAAAEGgK8ABEA1EBvARISQBMAEAwIAw8OCgkGAAwLDAkJCggHCA0HDQ4PDxADAgMEBAUODgQQDxARBxEAAQECAAABBwYHCAcICQYGBwUFBg8ODwwMDQsKCxAHEBEJCAkDAwQKCgsCAgoFBAIDAQERDg0LCgcGBwACAQZGdi83GAA/Fzw/FzwBhy4IxAjECMQI/AjECMQIxIcuCMQI/AjEhy4IxAj8CMSHLgjECMQIxAj8CMQIxAjEAS4uLi4uLgAuLi4uMTABSWi5AAYAEkloYbBAUlg4ETe5ABL/wDhZCQEjJwcjATMTNwMzFzczAxcTBBr+6L43N77+6KrNQYyqNzeqjEHNArz9RIqKArz9/6MBXomJ/qKjAgEAAAEAHgAAAtoCvAALAKJATwEMDEANAAgCCwoGBQQACAcIBQUGBAMECQcJCgsLAAIBAgMDBAoKAwsKCwgICQcGBwAHAAEFBAUCAgMGBgcBAQYKCQcDBgIEAwEDAAEBBEZ2LzcYAD8XPD8XPAGHLgjECMQIxAj8CMQIxAjEhy4IxAjECMQI/AjECMQIxAEuLi4uLi4ALi4xMAFJaLkABAAMSWhhsEBSWDgRN7kADP/AOFkhIycHIxMDMxc3MwMC2r6goL7//76goL7/29sBXgFe3Nz+ogAAAQAeAAAC2gK8AAgAdUA0AQkJQAoABwUABwYHCAcIAAEBAgAAAQYFBgcHBwgFBQYEBAUCAQQEAwMCAQgGBQMAAgEFRnYvNxgAPxc8PzwBLzz9PIcuCMQI/AjEhy4IxAj8CMQBLi4ALjEwAUlouQAFAAlJaGGwQFJYOBE3uQAJ/8A4WQkBESMRATMXNwLa/u2W/u2+oKACvP6E/sABQAF83NwAAQAeAAACdgK8AAkAcUAvAQoKQAsACAkIBwYFBAMCAQACAQIDBwMECAgJBwcICQIFAAQDBQUGBQIBAAEBAUZ2LzcYAD88PzwQ/TwQ/TwBhy4IxAj8CMQBLi4uLi4uLi4uLgAuMTABSWi5AAEACkloYbBAUlg4ETe5AAr/wDhZKQE1ASE1IRUBIQJ2/agBfv6CAlj+ggF+jAGkjIz+XAABAB4B4AC0ArwABQBNQBsBBgZABwAEAwQBBQAEAgEFBAUAAQADAgIBAUZ2LzcYAD88LzwQ/TwBLzz9PBD9PAAxMAFJaLkAAQAGSWhhsEBSWDgRN7kABv/AOFkTIzUzFTO0lktLAeDcUAAAAQAeAeAAtAK8AAUATUAbAQYGQAcAAgEEAAUABAQDAwIFBAEABQQCAQNGdi83GAA/PC88EP08AS88/TwQ/TwAMTABSWi5AAMABkloYbBAUlg4ETe5AAb/wDhZEyM1IzUztEtLlgHgUIwAAAEAHv+wALQAjAAFAEpAGQEGBkAHAAIBBAAFAAQEAwUEAQADAgEBA0Z2LzcYAD88LzwvPAEvPP08EP08ADEwAUlouQADAAZJaGGwQFJYOBE3uQAG/8A4WRcjNSM1M7RLS5ZQUIwAAAEAHgHgALQCvAAFAE1AGwEGBkAHAAIBBAMFAAQEAwEABQQDAgUEAgEDRnYvNxgAPzwvPBD9PAEvPP08EP08ADEwAUlouQADAAZJaGGwQFJYOBE3uQAG/8A4WRMjFSM1M7RLS5YCMFDcAAACAB4B4AFyArwABQALAGlALQEMDEANAAQDBAEKCQQHAgEEBQALBgQIBwsKBQMEBQAHBgEDAAkIAwMCAgEHRnYvNxgAPxc8Lxc8EP0XPAEvPP08Lzz9PBD9PBD9PAAxMAFJaLkABwAMSWhhsEBSWDgRN7kADP/AOFkBIzUzFTMHIzUzFTMBcpZLS76WS0sB4NxQjNxQAAACAB4B4AFyArwABQALAGlALQEMDEANAAIBBAAIBwQGBAMEBQALBgQKCQkIAwMCBQQHBgEDAAsKBQMEAgEJRnYvNxgAPxc8Lxc8EP0XPAEvPP08Lzz9PBD9PBD9PAAxMAFJaLkACQAMSWhhsEBSWDgRN7kADP/AOFkBIzUjNTMHIzUjNTMBcktLlr5LS5YB4FCM3FCMAAACAB7/sAFyAIwABQALAGZAKwEMDEANAAIBBAAIBwQGBAMEBQALBgQKCQsKBQMEBwYBAwAJCAMDAgEBCUZ2LzcYAD8XPC8XPC8XPAEvPP08Lzz9PBD9PBD9PAAxMAFJaLkACQAMSWhhsEBSWDgRN7kADP/AOFkFIzUjNTMHIzUjNTMBcktLlr5LS5ZQUIzcUIwAAAAAAAAAAAAAfAAAAHwAAAB8AAAAfAAAAPIAAAGIAAAB8gAAAlgAAAKuAAADSgAAA7QAAARgAAAFGAAABbQAAAZgAAAHFAAAB4QAAAhmAAAJGgAACZIAAAoaAAAK1AAAC5IAAAxUAAAM3gAADW4AAA4SAAAOoAAAD0QAAA/SAAAQKgAAELIAABFqAAAR3AAAEpYAABMwAAATzgAAFGYAABUGAAAVuAAAFmoAABbiAAAXagAAGAAAABkeAAAZ8gAAGpQAABsyAAAb8AAAHLIAAB08AAAdzAAAHnAAAB7+AAAfogAAIDAAACCIAAAhEAAAIcgAACI6AAAi9AAAI44AACQsAAAkxAAAJWQAACYWAAAmyAAAJ0AAACfIAAAoXgAAKXwAACpQAAAq8gAAK5AAACv6AAAsZAAALMoAAC00AAAtygAALmAAAC7yAfQAPwAAAAAA+gAAAPoAAADSAB4BkAAeANIAHgDSAB4A0gAeAmIAHgE2AB4CYgAeAmIAHgJiAB4CYgAeAmIAHgJiAB4CYgAeAmIAHgDSAB4A0gAeAf4AHgLuAAAClAAeAmIAHgKUAB4CYgAeAmIAHgKUAB4ClAAeANIAHgKUAB4C0AAeAmIAHgM0AB4ClAAeApQAHgKUAB4C+AAeApQAHgKUAB4ClAAeApQAHgLuAAAEGgAAAvgAHgL4AB4ClAAeAu4AAAKUAB4CYgAeApQAHgJiAB4CYgAeApQAHgKUAB4A0gAeApQAHgLQAB4CYgAeAzQAHgKUAB4ClAAeApQAHgL4AB4ClAAeApQAHgKUAB4ClAAeAu4AAAQaAAAC+AAeAvgAHgKUAB4A0gAeANIAHgDSAB4A0gAeAZAAHgGQAB4BkAAeAAIAAAAAAAD/ewAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAUQAAAAEAAgADAAQABQAKAA8AEQATABQAFQAWABcAGAAZABoAGwAcAB0AHgAiACQAJQAmACcAKAApACoAKwAsAC0ALgAvADAAMQAyADMANAA1ADYANwA4ADkAOgA7ADwAPQBEAEUARgBHAEgASQBKAEsATABNAE4ATwBQAFEAUgBTAFQAVQBWAFcAWABZAFoAWwBcAF0AtgC3AMQBAgC0ALUAxQ1xdW90ZXJldmVyc2VkAAAAAAADAAAAAAAABMQAAQAAAAAAHAADAAEAAATEAAYEpgAAAAACTgABAAAAAAAAAAAAAAAAAAAAAQADAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAwAEAAUAAAAAAAAAAAAGAAAAAAAAAAAABwAAAAgAAAAJAAoACwAMAA0ADgAPABAAEQASABMAFAAAAAAAAAAVAAAAFgAXABgAGQAaABsAHAAdAB4AHwAgACEAIgAjACQAJQAmACcAKAApACoAKwAsAC0ALgAvAAAAAAAAAAAAAAAAADAAMQAyADMANAA1ADYANwA4ADkAOgA7ADwAPQA+AD8AQABBAEIAQwBEAEUARgBHAEgASQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEoASwBMAE0ATgBPAFAAAAAEAP4AAAAUABAAAwAEACIAJwAsAC4AOwA/AFoAeiAe//8AAAAgACcALAAuADAAPwBBAGEgGP//AAAAAAAAAAAAAAAAAAAAAAAAAAEAFAAYABgAGAAYAC4ALgBgAJL//wADAAQABQAGAAcACAAJAAoACwAMAA0ADgAPABAAEQASABMAFAAVABYAFwAYABkAGgAbABwAHQAeAB8AIAAhACIAIwAkACUAJgAnACgAKQAqACsALAAtAC4ALwAwADEAMgAzADQANQA2ADcAOAA5ADoAOwA8AD0APgA/AEAAQQBCAEMARABFAEYARwBIAEkASgBLAEwATQBOAE8AUAAAAAAAAAABAAAB7gABAFAAJAAGAbwAFgAp/10AFgAr/1sAFgAs/1gAFgAu/zEAFgBD/10AFgBF/1sAFgBG/1gAFgBI/zEAGwAW/6QAGwAw/6QAIQAf/8EAIQAp/xUAIQAr/0QAIQAs/0EAIQAu/vIAIQA5/8EAIQBD/xUAIQBF/0QAIQBG/0EAIQBI/vIAJQAW/5IAJQAf/nIAJQAw/5IAJQA5/nIAKQAW/2cAKQAf/zMAKQAw/2cAKQA5/zMAKwAW/1sAKwAf/4IAKwAw/1sAKwA5/4IALAAW/1gALAAf/4AALAAw/1gALAA5/4AALgAW/zEALgAf/v0ALgAw/zEALgA5/v0AMAAp/10AMAAr/1sAMAAs/1gAMAAu/zEAMABD/10AMABF/1sAMABG/1gAMABI/zEANQAW/6QANQAw/6QAOwAf/8EAOwAp/xUAOwAr/0QAOwAs/0EAOwAu/vIAOwA5/8EAOwBD/xUAOwBF/0QAOwBG/0EAOwBI/vIAPwAW/5IAPwAf/nIAPwAw/5IAPwA5/nIAQwAW/2cAQwAf/zMAQwAw/2cAQwA5/zMARQAW/1sARQAf/4IARQAw/1sARQA5/4IARgAW/1gARgAf/4AARgAw/1gARgA5/4AASAAW/zEASAAf/v0ASAAw/zEASAA5/v0AAAAAABAAAABUCQkFAAICAgQCAgIFAwUFBQUFBQUFAgIFBwYFBgUFBgYCBgYFBwYGBgcGBgYGBwkHBwYHBgUGBQUGBgIGBgUHBgYGBwYGBgYHCQcHBgICAgIEBAQACgsFAAMDAgQCAgIGAwYGBgYGBgYGAgIFCAcGBwYGBwcCBwcGCAcHBwgHBwcHCAsICAcIBwYHBgYHBwIHBwYIBwcHCAcHBwcICwgIBwICAgIEBAQACwwGAAMDAgQCAgIHAwcHBwcHBwcHAgIGCAcHBwcHBwcCBwgHCQcHBwgHBwcHCAwICAcIBwcHBwcHBwIHCAcJBwcHCAcHBwcIDAgIBwICAgIEBAQADA0GAAMDAwUDAwMHBAcHBwcHBwcHAwMGCQgHCAcHCAgDCAkHCggICAkICAgICQ0JCQgJCAcIBwcICAMICQcKCAgICQgICAgJDQkJCAMDAwMFBQUADQ4HAAMDAwUDAwMIBAgICAgICAgIAwMHCgkICQgICQkDCQkICwkJCQoJCQkJCg4KCgkKCQgJCAgJCQMJCQgLCQkJCgkJCQkKDgoKCQMDAwMFBQUADg8HAAQEAwYDAwMJBAkJCQkJCQkJAwMHCwkJCQkJCQkDCQoJCwkJCQsJCQkJCw8LCwkLCQkJCQkJCQMJCgkLCQkJCwkJCQkLDwsLCQMDAwMGBgYADxAIAAQEAwYDAwMJBQkJCQkJCQkJAwMICwoJCgkJCgoDCgsJDAoKCgsKCgoKCxALCwoLCgkKCQkKCgMKCwkMCgoKCwoKCgoLEAsLCgMDAwMGBgYAEBEIAAQEAwYDAwMKBQoKCgoKCgoKAwMIDAsKCwoKCwsDCwwKDQsLCwwLCwsLDBEMDAsMCwoLCgoLCwMLDAoNCwsLDAsLCwsMEQwMCwMDAwMGBgYAERIJAAQEBAcEBAQKBQoKCgoKCgoKBAQJDQsKCwoKCwsECwwKDgsLCw0LCwsLDRINDQsNCwoLCgoLCwQLDAoOCwsLDQsLCwsNEg0NCwQEBAQHBwcAEhMJAAUFBAcEBAQLBgsLCwsLCwsLBAQJDgwLDAsLDAwEDA0LDwwMDA4MDAwMDhMODgwODAsMCwsMDAQMDQsPDAwMDgwMDAwOEw4ODAQEBAQHBwcAExQKAAUFBAgEBAQMBgwMDAwMDAwMBAQKDg0MDQwMDQ0EDQ4MEA0NDQ4NDQ0NDhQODg0ODQwNDAwNDQQNDgwQDQ0NDg0NDQ0OFA4ODQQEBAQICAgAFBUKAAUFBAgEBAQMBgwMDAwMDAwMBAQKDw0MDQwMDQ0EDQ4MEA0NDQ8NDQ0NDxUPDw0PDQwNDAwNDQQNDgwQDQ0NDw0NDQ0PFQ8PDQQEBAQICAgAFRYLAAUFBAgEBAQNBw0NDQ0NDQ0NBAQLEA4NDg0NDg4EDg8NEQ4ODhAODg4OEBYQEA4QDg0ODQ0ODgQODw0RDg4OEA4ODg4QFhAQDgQEBAQICAgAFhcLAAYGBQkFBQUNBw0NDQ0NDQ0NBQULEQ8NDw0NDw8FDxANEg8PDxEPDw8PERcREQ8RDw0PDQ0PDwUPEA0SDw8PEQ8PDw8RFxERDwUFBQUJCQkAFxgMAAYGBQkFBQUOBw4ODg4ODg4OBQUMEQ8ODw4ODw8FDxEOEw8PDxEPDw8PERgREQ8RDw4PDg4PDwUPEQ4TDw8PEQ8PDw8RGBERDwUFBQUJCQkAGBkMAAYGBQoFBQUPBw8PDw8PDw8PBQUMEhAPEA8PEBAFEBEPFBAQEBIQEBAQEhkSEhASEA8QDw8QEAUQEQ8UEBAQEhAQEBASGRISEAUFBQUKCgoAAAECPgGQAAUAAgK8AooAAACPArwCigAAAcUAMgEDAAAAAAQAAAAAAAAAAAAAAwAAAAAAAAAAAAAAAE1BQ1IAQAAgIB4CvP+wAAACvABQAAAAAQAAAAAAAAABAACAAAAAAPoCvAAAYAACvAJ1QWxpZW4gRW5jb3VuICAgIP////83///+QUxJUjAwAAAAAAAAAAEAAAABAACV2Yp0Xw889QAAA+gAAAAAsyRJvAAAAACzJEm8AAD/sAQaAyAAAAADAAIAAQAAAAAAAQAAAyD+1AAABBoAAAAABBoAAQAAAAAAAAAAAAAAAAAAAFEAAQAAAFEAJgADAAAAAAACAAgAQAAKAAAAcwDUAAEAAQ==") format("truetype");\n      font-weight: 400;\n      font-style: normal;\n    }\n    @font-face {\n      font-family: "AlienEncountersBold";\n      src: url("data:font/ttf;base64,AAEAAAAQAEAABADAT1MvMlG3ftgAAET0AAAAVlBDTFSCmPXWAABFTAAAADZjbWFwMhA+sAAAN/QAAAXCY3Z0IGO9YisAAAT0AAAAKmZwZ22DM8JPAAAE4AAAABRnbHlmJZF2cwAABYQAAC8QaGRteAW9X3MAAD+sAAAFSGhlYWTJd9cOAABFhAAAADZoaGVhBz0DOQAARbwAAAAkaG10eLSIBvAAADXcAAABRGtlcm7w1PfFAAA9uAAAAfJsb2NhAAc0VgAANJQAAAFIbWF4cADVATMAAEXgAAAAIG5hbWW6TWsOAAABDAAAA9Jwb3N0Z0BkhQAANyAAAADScHJlcJoTFEwAAAUgAAAAYQAAABgBJgAAAAAAAAAAAHoAPQAAAAAAAAABACwAzQAAAAAAAAACAAgA/QAAAAAAAAADAG4BjQAAAAAAAAAEADYBIAAAAAAAAAAFAEYCHgAAAAAAAAAGADACfAAAAAAAAAAHAAACrAABAAAAAAAAAD0AAAABAAAAAAABABYAtwABAAAAAAACAAQA+QABAAAAAAADADcBVgABAAAAAAAEABsBBQABAAAAAAAFACMB+wABAAAAAAAGABgCZAABAAAAAAAHAAACrAADAAEECQAAAHoAPQADAAEECQABACwAzQADAAEECQACAAgA/QADAAEECQADAG4BjQADAAEECQAEADYBIAADAAEECQAFAEYCHgADAAEECQAGADACfAADAAEECQAHAAACrHYxLjAgQ3JlYXRlZCBieSBTaHlXZWRnZSwgMTk5OS4gIChodHRwOi8vd2VsY29tZS50by9TaHlmb250cykAdgAxAC4AMAAgAEMAcgBlAGEAdABlAGQAIABiAHkAIABTAGgAeQBXAGUAZABnAGUALAAgADEAOQA5ADkALgAgACAAKABoAHQAdABwADoALwAvAHcAZQBsAGMAbwBtAGUALgB0AG8ALwBTAGgAeQBmAG8AbgB0AHMAKUFsaWVuIEVuY291bnRlcnMgU29saWQAQQBsAGkAZQBuACAARQBuAGMAbwB1AG4AdABlAHIAcwAgAFMAbwBsAGkAZEJvbGQAQgBvAGwAZEFsaWVuIEVuY291bnRlcnMgU29saWQgQm9sZABBAGwAaQBlAG4AIABFAG4AYwBvAHUAbgB0AGUAcgBzACAAUwBvAGwAaQBkACAAQgBvAGwAZE1hY3JvbWVkaWEgRm9udG9ncmFwaGVyIDQuMSBBbGllbiBFbmNvdW50ZXJzIFNvbGlkIEJvbGQATQBhAGMAcgBvAG0AZQBkAGkAYQAgAEYAbwBuAHQAbwBnAHIAYQBwAGgAZQByACAANAAuADEAIABBAGwAaQBlAG4AIABFAG4AYwBvAHUAbgB0AGUAcgBzACAAUwBvAGwAaQBkACAAQgBvAGwAZE1hY3JvbWVkaWEgRm9udG9ncmFwaGVyIDQuMSAzLzI4Lzk5AE0AYQBjAHIAbwBtAGUAZABpAGEAIABGAG8AbgB0AG8AZwByAGEAcABoAGUAcgAgADQALgAxACAAMwAvADIAOAAvADkAOUFsaWVuRW5jb3VudGVyc1NvbGlkQm9sZABBAGwAaQBlAG4ARQBuAGMAbwB1AG4AdABlAHIAcwBTAG8AbABpAGQAQgBvAGwAZAAAQAEALHZFILADJUUjYWgYI2hgRC3/OP/2AsEBKgCgAJYAYwCpAHQAQADIAa4B9AGGAV4B9AHMWmJaYgACAAQAAEAbEBAPDw4ODQ0MDAsLCgoJCQgIBwcCAgEBAAABjbgB/4VFaERFaERFaERFaERFaERFaERFaERFaERFaERFaERFaERFaERFaESzBANGACuzBgVGACuxAwNFaESxBQVFaEQAAAAAAgA/AAABtgMgAAMABwBWQCABCAhACQIHBAQBAAYFBAMCBQQGAAcGBgECAQMAAQEARnYvNxgAPzwvPBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkAAAAISWhhsEBSWDgRN7kACP/AOFkzESERJTMRIz8Bd/7H+voDIPzgPwKjAAIAGf/7ALkCwQADAAcAU0AgAQgIQAkAAQAHBAMDAAQGBQIDAQcGBQQFBAEDAgIBAUZ2LzcYAD88PzwQ/TwBLxc8/Rc8AC4uMTABSWi5AAEACEloYbBAUlg4ETe5AAj/wDhZNyMRMxEjNTO5oKCgoOsB1v06lgACABkB2wF3AsEABQALAGlALQEMDEANAAIBBAAIBwQGBAMEBQALBgQKCQkIAwMCBQQHBgEDAAsKBQMEAgEJRnYvNxgAPxc8Lxc8EP0XPAEvPP08Lzz9PBD9PBD9PAAxMAFJaLkACQAMSWhhsEBSWDgRN7kADP/AOFkBIzUjNTMHIzUjNTMBd1VLoL5VS6AB21CW5lCWAAABABkB2wC5AsEABQBNQBsBBgZABwACAQQABQAEBAMDAgUEAQAFBAIBA0Z2LzcYAD88LzwQ/TwBLzz9PBD9PAAxMAFJaLkAAwAGSWhhsEBSWDgRN7kABv/AOFkTIzUjNTO5VUugAdtQlgAAAQAZ/6sAuQCRAAUASkAZAQYGQAcAAgEEAAUABAQDBQQBAAMCAQEDRnYvNxgAPzwvPC88AS88/TwQ/TwAMTABSWi5AAMABkloYbBAUlg4ETe5AAb/wDhZFyM1IzUzuVVLoFVQlgAAAQAZ//sAuQCRAAMAP0ATAQQEQAUAAwAEAgEDAgEAAQEBRnYvNxgAPzwvPAEvPP08ADEwAUlouQABAARJaGGwQFJYOBE3uQAE/8A4WRcjNTO5oKAFlgACABn/+wJJAsEADwATAFdAIQEUFEAVABMSBAgHERAEDwATEAUDEhEFCwwLAgQDAQEHRnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABwAUSWhhsEBSWDgRN7kAFP/AOFklFAYjISImNRE0NjMhMhYVAxEjEQJJPiv+ois+PisBXis+oPBkKz4+KwH0Kz4+K/45AZr+ZgABABn/+wEdAsEABQBOQBwBBgZABwAEAwMAAgEEBQADAgUEBQQCAQABAQNGdi83GAA/PD88EP08AS88/TwQ/TwAMTABSWi5AAMABkloYbBAUlg4ETe5AAb/wDhZBSMRIzUhAR2gZAEEBQIwlgABABn/+wJJAsEAFABoQCwBFRVAFgATEgQJCAIDAQcGBBQODQMAFBMFAAgHBQkSEQUGBQoJAgEAAQEBRnYvNxgAPzw/PC88/TwQ/TwQ/TwBLxc8/TwvFzz9PAAxMAFJaLkAAQAVSWhhsEBSWDgRN7kAFf/AOFkFIRE0NjMhNSE1ITIWHQEUBiMhFSECSf3QPisBJ/5wAccrPj4r/tkBkAUBbSs+WpY+K7QrPqoAAQAZ//sCSQLBABgAbkAvARkZQBoADQwFBAkIAxULCgcDBgQYEhEDAAYFBQMIBwUKCQwLBQ0ODQIEAwEBBEZ2LzcYAD88PzwQ/TwvPP08EP08AS8XPP0XPC/9PC4uLi4AMTABSWi5AAQAGUloYbBAUlg4ETe5ABn/wDhZJRQGIyE1ITUjNTM1ITUhMhYdARQGBx4BFQJJPiv+OQGQyMj+cAHHKz4pICApZCs+lqqWWpY+K24jNwoKNyMAAQAZ//sCSQLBAA0AakAvAQ4OQA8ADQAKCQQDAwQMCwIDAQgHBAYFBQQBAwAFDQwJAwgLCgcDBgIDAgEBBUZ2LzcYAD88Pxc8Lxc8/Rc8AS88/TwvFzz9FzwuLgAxMAFJaLkABQAOSWhhsEBSWDgRN7kADv/AOFkBIxEjESERMxUzNTMVMwJJMqD+oqC+oDIBO/7AAUABhvDw8AAAAQAZ//sCSQLBABQAaEAsARUVQBYABwYEFA4NAwAQDwQMCwUDBAYFBQMIBwUREA8OBQwNDAIEAwEBBEZ2LzcYAD88PzwQ/TwvPP08EP08AS8XPP08Lxc8/TwAMTABSWi5AAQAFUloYbBAUlg4ETe5ABX/wDhZJRQGIyE1ITUhIiY1ESEVIRUhMhYVAkk+K/45AZD+2Ss+AjD+cAEnKz5kKz6Wqj4rAR2WWj4rAAIAGf/7AkkCwQATABcAaEArARgYQBkADQwXFg8DDgQIBxUUBBMAFxQFAw4NBQsWFQUQDwwLAgQDAQEHRnYvNxgAPzw/PC88/TwQ/TwQ/TwBLzz9PC88/Rc8Li4AMTABSWi5AAcAGEloYbBAUlg4ETe5ABj/wDhZJRQGIyEiJjURNDYzIRUhFSEyFhUHNSMVAkk+K/6iKz4+KwGV/qIBJys+oPBkKz4+KwH0Kz6WWj4r16qqAAEAGf/7AkkCwQAIAEtAGgEJCUAKAAQDAgEECAADAgUEBQQCAQABAQNGdi83GAA/PD88EP08AS88/TwuLgAxMAFJaLkAAwAJSWhhsEBSWDgRN7kACf/AOFkFIxEhNSEyFhUCSaD+cAHHKz4FAjCWPisAAAMAGf/7AkkCwQAdACEAJQB0QDQBJiZAJwAaCyUkIQMgBA8OCAMHIyIfAx4EHRcWAwAlIgUDIB8FEiQjBSEeExICBAMBAQdGdi83GAA/PD88Lzz9PBD9PBD9PAEvFzz9FzwvFzz9FzwuLgAxMAFJaLkABwAmSWhhsEBSWDgRN7kAJv/AOFklFAYjISImPQE0NjcuAT0BNDYzITIWHQEUBgceARUnNSMVEzUjFQJJPiv+ois+KSAgKT4rAV4rPikgICmg8PDwZCs+Piu+IzcKCjcjbis+PituIzcKCjcjr1pa/sCqqgAAAgAZ//sCSQLBABMAFwBoQCsBGBhAGQAFBBUUBwMGBBMAFxYEDAsGBQUDFxQFCAcWFQUPEA8CBAMBAQtGdi83GAA/PD88EP08Lzz9PBD9PAEvPP08Lzz9FzwuLgAxMAFJaLkACwAYSWhhsEBSWDgRN7kAGP/AOFklFAYjITUhNSEiJjURNDYzITIWFQc1IxUCST4r/msBXv7ZKz4+KwFeKz6g8GQrPpZaPisBBCs+PivXqqoAAgAZ//sAuQHRAAMABwBVQCEBCAhACQAHBAMDAAQGBQIDAQEABQIHBgUEAwIFBAEBAUZ2LzcYAD88LzwQ/TwQ/TwBLxc8/Rc8ADEwAUlouQABAAhJaGGwQFJYOBE3uQAI/8A4WRMjNTMRIzUzuaCgoKABO5b+KpYAAgAZ/6sAuQHRAAMACQBgQCcBCgpACwAGBQQACQQDAwAECAcCAwEBAAUCCQgFBgMCBQQHBgEBAUZ2LzcYAD88LzwvPBD9PBD9PAEvFzz9FzwQ/TwAMTABSWi5AAEACkloYbBAUlg4ETe5AAr/wDhZEyM1MxEjNSM1M7mgoFVLoAE7lv3aUJYAAAIAGf/7AeUCwQASABYAcUAyARcXQBgAFhMFAwQEFRQODQcFBgwLBBIABgUFCgQDBQsKDQwFDhYVBRMUEwEPDgIBBkZ2LzcYAD88PzwQ/TwQ/TwvPP08EP08AS88/TwvFzz9FzwAMTABSWi5AAYAF0loYbBAUlg4ETe5ABf/wDhZARQGKwEVIzU0NjsBNSE1ITIWFQEjNTMB5T4rw6A+K8P+1AFjKz7+1KCgAaQrPlB9Kz5alj4r/aOWAAL/+f/7AvUCwQAHAAoAjUBCAQsLQAwACQoIBQAKCggDAgMJCAkEBwQFBgYHBQUGCAoIAgIDAQABCQcJCgAAAQcHAAoIBQMCBwYCBQQBAwABAQVGdi83GAA/Fzw/PC88/TwBhy4IxAj8CMQIxAjEhy4IxAj8CMQIxAjEAS4uLi4ALjEwAUlouQAFAAtJaGGwQFJYOBE3uQAL/8A4WQUjJyEHIwEzAycHAvW0QP7sQLQBHMQUTk4FoKACxv5ww8MAAAMAGf/7AnsCwQAQABQAGABuQDABGRlAGgANGBcUAxMEBQQWFRIDEQQQCgkDABgVBQMTEgUFFxYFFBEGBQIEAwEBBEZ2LzcYAD88PzwvPP08EP08EP08AS8XPP0XPC88/Rc8LgAxMAFJaLkABAAZSWhhsEBSWDgRN7kAGf/AOFklFAYjIREhMhYdARQGBx4BFSc1IRUBNSEVAns+K/4HAfkrPikgICmg/t4BIv7eZCs+AsY+K24jNwoKNyOvWlr+wKqqAAABABn/+wJJAsEADQBWQCABDg5ADwANCgkADAsEBQQNDAUACwoFCAkIAgEAAQEERnYvNxgAPzw/PBD9PBD9PAEvPP08Li4uLgAxMAFJaLkABAAOSWhhsEBSWDgRN7kADv/AOFkFISImNRE0NjMhFSERIQJJ/jkrPj4rAcf+cAGQBT4rAfQrPpb+ZgACABn/+wJ7AsEACQANAFdAIQEODkAPAA0MBAUECwoECQANCgUDDAsFBQYFAgQDAQEERnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABAAOSWhhsEBSWDgRN7kADv/AOFklFAYjIREhMhYVAxEhEQJ7Piv+BwH5Kz6g/t5kKz4Cxj4r/jkBmv5mAAABABn/+wJJAsEAEQBnQCoBEhJAEwARDg0KCQAQDwwDCwQFBBEQBQALCgUIDw4FDQwJCAIBAAEBBEZ2LzcYAD88PzwvPP08EP08EP08AS88/Rc8Li4uLi4uADEwAUlouQAEABJJaGGwQFJYOBE3uQAS/8A4WQUhIiY1ETQ2MyEVIRUhFSEVIQJJ/jkrPj4rAcf+cAGQ/nABkAU+KwH0Kz6WWpaqAAEAGf/7AkkCwQAMAFxAJAENDUAOAAwJCAALCgIDAQQEAwEABQwLCgkFBwgHAgMCAQEDRnYvNxgAPzw/PBD9PC88/TwBLzz9FzwuLi4uADEwAUlouQADAA1JaGGwQFJYOBE3uQAN/8A4WQEhESMRNDYzIRUhFSECSf5woD4rAcf+cAGQATv+wAJdKz6WWgABABn/+wJ7AsEAEQBoQCsBEhJAEwAQDwwLBAUEDg0EEQoJAwANDAUACwoFCA8OBREQCQgCAQABAQRGdi83GAA/PD88Lzz9PBD9PBD9PAEvFzz9PC88/TwuLgAxMAFJaLkABAASSWhhsEBSWDgRN7kAEv/AOFkFISImNRE0NjMhFSERITUjNSECe/4HKz4+KwH5/j4BIsgBaAU+KwH0Kz6W/maqlgAAAQAZ//sCewLBAAsAYkAqAQwMQA0ACgkCAwEECwAIBwQDAwQGBQMCBQkICwoHAwYCBQQBAwABAQVGdi83GAA/Fzw/FzwvPP08AS88/Rc8Lzz9FzwAMTABSWi5AAUADEloYbBAUlg4ETe5AAz/wDhZBSMRIREjETMVITUzAnug/t6goAEioAUBQP7AAsbw8AAAAQAZ//sAuQLBAAMAQEAUAQQEQAUAAwAEAgEDAgIBAAEBAUZ2LzcYAD88PzwBLzz9PAAxMAFJaLkAAQAESWhhsEBSWDgRN7kABP/AOFkXIxEzuaCgBQLGAAEAGf/7AnsCwQANAFdAIQEODkAPAAoJBAgHDAsEDQAJCAUDCwoFAw0MAgQDAQEHRnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABwAOSWhhsEBSWDgRN7kADv/AOFklFAYjISImPQEzFSERMwJ7Piv+cCs+oAEioGQrPj4rzaACMAABABn/+wK8AsEACgCJQEABCwtADAAHAgoJAAoKAAIBAgkICQMHAwQICAkHBwgKCQoABwABAgIDAQECBwMGBAUECQgGAwUCBAMBAwABAQRGdi83GAA/Fzw/FzwBLzz9PDyHLgjECPwIxIcuCMQI/AjECMQIxAEuLi4ALi4xMAFJaLkABAALSWhhsEBSWDgRN7kAC//AOFkFIycHIxEzEQEzAQK8y52dnqABOMv+/QXY2ALG/lMBrf6dAAABABn/+wJJAsEACABLQBoBCQlACgAIAAcGBAUECAcFAAYFAgEAAQEERnYvNxgAPzw/PBD9PAEvPP08Li4AMTABSWi5AAQACUloYbBAUlg4ETe5AAn/wDhZBSEiJjURMxEhAkn+OSs+oAGQBT4rAl390AABABn/+wMbAsEADACGQD8BDQ1ADgAKBQIKCQoLBwsMAwMEAgIDCQgJCgcKCwUFBgQEBQsCAQQMAAYFBAgHDAsJAwgCBwYEAwEFAAEBB0Z2LzcYAD8XPD8XPAEvPP08Lzz9PDyHLgjECPwIxIcuCMQI/AjEAQAuLi4xMAFJaLkABwANSWhhsEBSWDgRN7kADf/AOFkFIxEDIwMRIxEzGwEzAxugon6ioJ7h5Z4FAU3+swFN/rMCxv4rAdUAAAEAGf/7AnsCwQAJAGtALgEKCkALAAcCBgUGBwcHCAICAwEBAgMCBAUECAcECQAJCAYDBQIEAwEDAAEBBEZ2LzcYAD8XPD8XPAEvPP08Lzz9PIcuCMQI/AjEAQAuLjEwAUlouQAEAApJaGGwQFJYOBE3uQAK/8A4WQUjAREjETMBETMCe57+3KCeASSgBQGZ/mcCxv5nAZkAAgAZ//sCewLBAA8AEwBXQCEBFBRAFQATEgQIBxEQBA8AExAFAxIRBQsMCwIEAwEBB0Z2LzcYAD88PzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAcAFEloYbBAUlg4ETe5ABT/wDhZJRQGIyEiJjURNDYzITIWFQMRIRECez4r/nArPj4rAZArPqD+3mQrPj4rAfQrPj4r/jkBmv5mAAACABn/+wJ7AsEACwAPAF1AJQEQEEARAA8OBQMEBAcGDQwECwAEAwUPDA4NBQcIBwIGBQEBBkZ2LzcYAD88PzwQ/TwvPP08AS88/TwvPP0XPAAxMAFJaLkABgAQSWhhsEBSWDgRN7kAEP/AOFkBFAYjIREjESEyFhUHNSEVAns+K/6noAH5Kz6g/t4BpCs+/sACxj4rh1paAAIAGf/7At8CwQAOABIAX0AmARMTQBQADgASEQQFBBAPBA0MEg8OAw0FABEQBQgJCAIBAAEBBEZ2LzcYAD88PzwQ/TwQ/Rc8AS88/TwvPP08Li4AMTABSWi5AAQAE0loYbBAUlg4ETe5ABP/wDhZBSEiJjURNDYzITIWFREzIREhEQLf/aMrPj4rAZArPmT+/P7eBT4rAfQrPj4r/jkBmv5mAAIAGf/7AnsCwQARABUAa0AvARYWQBcADhMSAgMBBBELCgMAFRQEAwMEBgUDAgUVEhQTBQYHBgIFBAEDAAEBBUZ2LzcYAD8XPD88EP08Lzz9PAEvPP0XPC8XPP0XPC4AMTABSWi5AAUAFkloYbBAUlg4ETe5ABb/wDhZBSMRIREjESEyFh0BFAYHHgEVJzUhFQJ7oP7eoAH5Kz4pICApoP7eBQFA/sACxj4rbiM3Cgo3I69aWgAAAQAZ//sCewLBABcAaEAsARgYQBkABwYEFxEQAwATEgQMCwUDBAYFBQMIBwUUExIRBQ8QDwIEAwEBBEZ2LzcYAD88PzwQ/TwvPP08EP08AS8XPP08Lxc8/TwAMTABSWi5AAQAGEloYbBAUlg4ETe5ABj/wDhZJRQGIyE1ITUhIiY9ATQ2MyEVIRUhMhYVAns+K/4HAcL+pys+PisB+f4+AVkrPmQrPpaqPiu0Kz6WWj4rAAEAGf/7AnsCwQAHAFNAHwEICEAJAAcGBQAEAwQCAQUEAQMABQYHBgIDAgEBBUZ2LzcYAD88PzwQ/Rc8AS88/TwuLi4uADEwAUlouQAFAAhJaGGwQFJYOBE3uQAI/8A4WQEjESMRIzUhAnvXoOsCYgIr/dACMJYAAAEAGf/7AnsCwQANAFRAIAEODkAPAAoJBAgHDAsEDQALCgUDDQwJAwgCBAMBAQdGdi83GAA/PD8XPBD9PAEvPP08Lzz9PAAxMAFJaLkABwAOSWhhsEBSWDgRN7kADv/AOFklFAYjISImNREzESERMwJ7Piv+cCs+oAEioGQrPj4rAl390AIwAAAB//n/+wL1AsEABgBsQC8BBwdACAAFAwAFBAUGBwYAAQECAAABBAMEBQcFBgMDBAICAwIBAQYEAwMAAgEDRnYvNxgAPxc8PzwBhy4IxAj8CMSHLgjECPwIxAEuLgAuMTABSWi5AAMAB0loYbBAUlg4ETe5AAf/wDhZCQEjATMbAQL1/uTE/uS0ysoCwf06Asb+BwH5AAAB//n/+wQhAsEAEQDKQGkBEhJAEwAQDAgDDw4KCQYADAsMCQkKCAcIDQcNDg8PEAMCAwQEBQ4OBBAPEBEHEQABAQIAAAEHBgcIBwgJBgYHBQUGDw4PCwoLEAcQEQkICQoKCwICCgUEAgMBAREODQsKBwYHAAIBBkZ2LzcYAD8XPD8XPAGHLgjECMQI/AjECMSHLgjECPwIxIcuCMQI/AjEhy4IxAjECMQI/AjECMQIxAEuLi4uLi4ALi4uLjEwAUlouQAGABJJaGGwQFJYOBE3uQAS/8A4WQkBIycHIwEzEzcDMxc3MwMXEwQh/uTENDTE/uS0yjyOtDQ0tI48ygLB/TqBgQLG/geWAWOBgf6dlgH5AAABABT/+wLkAsEACwCiQE8BDAxADQAIAgsKBgUEAAgHCAUFBgQDBAkHCQoLCwACAQIDAwQKCgMLCgsICAkHBgcABwABBQQFAgIDBgYHAQEGCgkHAwYCBAMBAwABAQRGdi83GAA/Fzw/FzwBhy4IxAjECMQI/AjECMQIxIcuCMQIxAjECPwIxAjECMQBLi4uLi4uAC4uMTABSWi5AAQADEloYbBAUlg4ETe5AAz/wDhZBSMnByMJATMXNzMBAuTLnZ3LAQP+/cudncv+/QXY2AFjAWPY2P6dAAABABT/+wLkAsEACAB1QDQBCQlACgAHBQAHBgcIBwgAAQECAAABBgUGBwcHCAUFBgQEBQIBBAQDAwIBCAYFAwACAQVGdi83GAA/Fzw/PAEvPP08hy4IxAj8CMSHLgjECPwIxAEuLgAuMTABSWi5AAUACUloYbBAUlg4ETe5AAn/wDhZCQERIxEBMxc3AuT+6KD+6MudnQLB/n3+vQFDAYPY2AABABn/+wJ7AsEACQBvQC4BCgpACwAJCAcGBQQDAgEABwYHCAcICQMDBAICAwkIBQAEAwUFBgUCAQABAQFGdi83GAA/PD88EP08EP08AYcuCMQI/AjEAS4uLi4uLi4uLi4AMTABSWi5AAEACkloYbBAUlg4ETe5AAr/wDhZBSE1ASE1IRUBIQJ7/Z4BeP6IAmL+iAF4BZMBnZaT/mMAAAL/+f/7AvUCwQAHAAoAjUBCAQsLQAwACQoIBQAKCggDAgMJCAkEBwQFBgYHBQUGCAoIAgIDAQABCQcJCgAAAQcHAAoIBQMCBwYCBQQBAwABAQVGdi83GAA/Fzw/PC88/TwBhy4IxAj8CMQIxAjEhy4IxAj8CMQIxAjEAS4uLi4ALjEwAUlouQAFAAtJaGGwQFJYOBE3uQAL/8A4WQUjJyEHIwEzAycHAvW0QP7sQLQBHMQUTk4FoKACxv5ww8MAAAMAGf/7AnsCwQAQABQAGABuQDABGRlAGgANGBcUAxMEBQQWFRIDEQQQCgkDABgVBQMTEgUFFxYFFBEGBQIEAwEBBEZ2LzcYAD88PzwvPP08EP08EP08AS8XPP0XPC88/Rc8LgAxMAFJaLkABAAZSWhhsEBSWDgRN7kAGf/AOFklFAYjIREhMhYdARQGBx4BFSc1IRUBNSEVAns+K/4HAfkrPikgICmg/t4BIv7eZCs+AsY+K24jNwoKNyOvWlr+wKqqAAABABn/+wJJAsEADQBWQCABDg5ADwANCgkADAsEBQQNDAUACwoFCAkIAgEAAQEERnYvNxgAPzw/PBD9PBD9PAEvPP08Li4uLgAxMAFJaLkABAAOSWhhsEBSWDgRN7kADv/AOFkFISImNRE0NjMhFSERIQJJ/jkrPj4rAcf+cAGQBT4rAfQrPpb+ZgACABn/+wJ7AsEACQANAFdAIQEODkAPAA0MBAUECwoECQANCgUDDAsFBQYFAgQDAQEERnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABAAOSWhhsEBSWDgRN7kADv/AOFklFAYjIREhMhYVAxEhEQJ7Piv+BwH5Kz6g/t5kKz4Cxj4r/jkBmv5mAAABABn/+wJJAsEAEQBnQCoBEhJAEwARDg0KCQAQDwwDCwQFBBEQBQALCgUIDw4FDQwJCAIBAAEBBEZ2LzcYAD88PzwvPP08EP08EP08AS88/Rc8Li4uLi4uADEwAUlouQAEABJJaGGwQFJYOBE3uQAS/8A4WQUhIiY1ETQ2MyEVIRUhFSEVIQJJ/jkrPj4rAcf+cAGQ/nABkAU+KwH0Kz6WWpaqAAEAGf/7AkkCwQAMAFxAJAENDUAOAAwJCAALCgIDAQQEAwEABQwLCgkFBwgHAgMCAQEDRnYvNxgAPzw/PBD9PC88/TwBLzz9FzwuLi4uADEwAUlouQADAA1JaGGwQFJYOBE3uQAN/8A4WQEhESMRNDYzIRUhFSECSf5woD4rAcf+cAGQATv+wAJdKz6WWgABABn/+wJ7AsEAEQBoQCsBEhJAEwAQDwwLBAUEDg0EEQoJAwANDAUACwoFCA8OBREQCQgCAQABAQRGdi83GAA/PD88Lzz9PBD9PBD9PAEvFzz9PC88/TwuLgAxMAFJaLkABAASSWhhsEBSWDgRN7kAEv/AOFkFISImNRE0NjMhFSERITUjNSECe/4HKz4+KwH5/j4BIsgBaAU+KwH0Kz6W/maqlgAAAQAZ//sCewLBAAsAYkAqAQwMQA0ACgkCAwEECwAIBwQDAwQGBQMCBQkICwoHAwYCBQQBAwABAQVGdi83GAA/Fzw/FzwvPP08AS88/Rc8Lzz9FzwAMTABSWi5AAUADEloYbBAUlg4ETe5AAz/wDhZBSMRIREjETMVITUzAnug/t6goAEioAUBQP7AAsbw8AAAAQAZ//sAuQLBAAMAQEAUAQQEQAUAAwAEAgEDAgIBAAEBAUZ2LzcYAD88PzwBLzz9PAAxMAFJaLkAAQAESWhhsEBSWDgRN7kABP/AOFkXIxEzuaCgBQLGAAEAGf/7AnsCwQANAFdAIQEODkAPAAoJBAgHDAsEDQAJCAUDCwoFAw0MAgQDAQEHRnYvNxgAPzw/PBD9PBD9PAEvPP08Lzz9PAAxMAFJaLkABwAOSWhhsEBSWDgRN7kADv/AOFklFAYjISImPQEzFSERMwJ7Piv+cCs+oAEioGQrPj4rzaACMAABABn/+wK8AsEACgCJQEABCwtADAAHAgoJAAoKAAIBAgkICQMHAwQICAkHBwgKCQoABwABAgIDAQECBwMGBAUECQgGAwUCBAMBAwABAQRGdi83GAA/Fzw/FzwBLzz9PDyHLgjECPwIxIcuCMQI/AjECMQIxAEuLi4ALi4xMAFJaLkABAALSWhhsEBSWDgRN7kAC//AOFkFIycHIxEzEQEzAQK8y52dnqABOMv+/QXY2ALG/lMBrf6dAAABABn/+wJJAsEACABLQBoBCQlACgAIAAcGBAUECAcFAAYFAgEAAQEERnYvNxgAPzw/PBD9PAEvPP08Li4AMTABSWi5AAQACUloYbBAUlg4ETe5AAn/wDhZBSEiJjURMxEhAkn+OSs+oAGQBT4rAl390AABABn/+wMbAsEADACGQD8BDQ1ADgAKBQIKCQoLBwsMAwMEAgIDCQgJCgcKCwUFBgQEBQsCAQQMAAYFBAgHDAsJAwgCBwYEAwEFAAEBB0Z2LzcYAD8XPD8XPAEvPP08Lzz9PDyHLgjECPwIxIcuCMQI/AjEAQAuLi4xMAFJaLkABwANSWhhsEBSWDgRN7kADf/AOFkFIxEDIwMRIxEzGwEzAxugon6ioJ7h5Z4FAU3+swFN/rMCxv4rAdUAAAEAGf/7AnsCwQAJAGtALgEKCkALAAcCBgUGBwcHCAICAwEBAgMCBAUECAcECQAJCAYDBQIEAwEDAAEBBEZ2LzcYAD8XPD8XPAEvPP08Lzz9PIcuCMQI/AjEAQAuLjEwAUlouQAEAApJaGGwQFJYOBE3uQAK/8A4WQUjAREjETMBETMCe57+3KCeASSgBQGZ/mcCxv5nAZkAAgAZ//sCewLBAA8AEwBXQCEBFBRAFQATEgQIBxEQBA8AExAFAxIRBQsMCwIEAwEBB0Z2LzcYAD88PzwQ/TwQ/TwBLzz9PC88/TwAMTABSWi5AAcAFEloYbBAUlg4ETe5ABT/wDhZJRQGIyEiJjURNDYzITIWFQMRIRECez4r/nArPj4rAZArPqD+3mQrPj4rAfQrPj4r/jkBmv5mAAACABn/+wJ7AsEACwAPAF1AJQEQEEARAA8OBQMEBAcGDQwECwAEAwUPDA4NBQcIBwIGBQEBBkZ2LzcYAD88PzwQ/TwvPP08AS88/TwvPP0XPAAxMAFJaLkABgAQSWhhsEBSWDgRN7kAEP/AOFkBFAYjIREjESEyFhUHNSEVAns+K/6noAH5Kz6g/t4BpCs+/sACxj4rh1paAAIAGf/7At8CwQAOABIAX0AmARMTQBQADgASEQQFBBAPBA0MEg8OAw0FABEQBQgJCAIBAAEBBEZ2LzcYAD88PzwQ/TwQ/Rc8AS88/TwvPP08Li4AMTABSWi5AAQAE0loYbBAUlg4ETe5ABP/wDhZBSEiJjURNDYzITIWFREzIREhEQLf/aMrPj4rAZArPmT+/P7eBT4rAfQrPj4r/jkBmv5mAAIAGf/7AnsCwQARABUAa0AvARYWQBcADhMSAgMBBBELCgMAFRQEAwMEBgUDAgUVEhQTBQYHBgIFBAEDAAEBBUZ2LzcYAD8XPD88EP08Lzz9PAEvPP0XPC8XPP0XPC4AMTABSWi5AAUAFkloYbBAUlg4ETe5ABb/wDhZBSMRIREjESEyFh0BFAYHHgEVJzUhFQJ7oP7eoAH5Kz4pICApoP7eBQFA/sACxj4rbiM3Cgo3I69aWgAAAQAZ//sCewLBABcAaEAsARgYQBkABwYEFxEQAwATEgQMCwUDBAYFBQMIBwUUExIRBQ8QDwIEAwEBBEZ2LzcYAD88PzwQ/TwvPP08EP08AS8XPP08Lxc8/TwAMTABSWi5AAQAGEloYbBAUlg4ETe5ABj/wDhZJRQGIyE1ITUhIiY9ATQ2MyEVIRUhMhYVAns+K/4HAcL+pys+PisB+f4+AVkrPmQrPpaqPiu0Kz6WWj4rAAEAGf/7AnsCwQAHAFNAHwEICEAJAAcGBQAEAwQCAQUEAQMABQYHBgIDAgEBBUZ2LzcYAD88PzwQ/Rc8AS88/TwuLi4uADEwAUlouQAFAAhJaGGwQFJYOBE3uQAI/8A4WQEjESMRIzUhAnvXoOsCYgIr/dACMJYAAAEAGf/7AnsCwQANAFRAIAEODkAPAAoJBAgHDAsEDQALCgUDDQwJAwgCBAMBAQdGdi83GAA/PD8XPBD9PAEvPP08Lzz9PAAxMAFJaLkABwAOSWhhsEBSWDgRN7kADv/AOFklFAYjISImNREzESERMwJ7Piv+cCs+oAEioGQrPj4rAl390AIwAAAB//n/+wL1AsEABgBsQC8BBwdACAAFAwAFBAUGBwYAAQECAAABBAMEBQcFBgMDBAICAwIBAQYEAwMAAgEDRnYvNxgAPxc8PzwBhy4IxAj8CMSHLgjECPwIxAEuLgAuMTABSWi5AAMAB0loYbBAUlg4ETe5AAf/wDhZCQEjATMbAQL1/uTE/uS0ysoCwf06Asb+BwH5AAAB//n/+wQhAsEAEQDKQGkBEhJAEwAQDAgDDw4KCQYADAsMCQkKCAcIDQcNDg8PEAMCAwQEBQ4OBBAPEBEHEQABAQIAAAEHBgcIBwgJBgYHBQUGDw4PCwoLEAcQEQkICQoKCwICCgUEAgMBAREODQsKBwYHAAIBBkZ2LzcYAD8XPD8XPAGHLgjECMQI/AjECMSHLgjECPwIxIcuCMQI/AjEhy4IxAjECMQI/AjECMQIxAEuLi4uLi4ALi4uLjEwAUlouQAGABJJaGGwQFJYOBE3uQAS/8A4WQkBIycHIwEzEzcDMxc3MwMXEwQh/uTENDTE/uS0yjyOtDQ0tI48ygLB/TqBgQLG/geWAWOBgf6dlgH5AAABABT/+wLkAsEACwCiQE8BDAxADQAIAgsKBgUEAAgHCAUFBgQDBAkHCQoLCwACAQIDAwQKCgMLCgsICAkHBgcABwABBQQFAgIDBgYHAQEGCgkHAwYCBAMBAwABAQRGdi83GAA/Fzw/FzwBhy4IxAjECMQI/AjECMQIxIcuCMQIxAjECPwIxAjECMQBLi4uLi4uAC4uMTABSWi5AAQADEloYbBAUlg4ETe5AAz/wDhZBSMnByMJATMXNzMBAuTLnZ3LAQP+/cudncv+/QXY2AFjAWPY2P6dAAABABT/+wLkAsEACAB1QDQBCQlACgAHBQAHBgcIBwgAAQECAAABBgUGBwcHCAUFBgQEBQIBBAQDAwIBCAYFAwACAQVGdi83GAA/Fzw/PAEvPP08hy4IxAj8CMSHLgjECPwIxAEuLgAuMTABSWi5AAUACUloYbBAUlg4ETe5AAn/wDhZCQERIxEBMxc3AuT+6KD+6MudnQLB/n3+vQFDAYPY2AABABn/+wJ7AsEACQBvQC4BCgpACwAJCAcGBQQDAgEABwYHCAcICQMDBAICAwkIBQAEAwUFBgUCAQABAQFGdi83GAA/PD88EP08EP08AYcuCMQI/AjEAS4uLi4uLi4uLi4AMTABSWi5AAEACkloYbBAUlg4ETe5AAr/wDhZBSE1ASE1IRUBIQJ7/Z4BeP6IAmL+iAF4BZMBnZaT/mMAAAEAGQHbALkCwQAFAE1AGwEGBkAHAAQDBAEFAAQCAQUEBQABAAMCAgEBRnYvNxgAPzwvPBD9PAEvPP08EP08ADEwAUlouQABAAZJaGGwQFJYOBE3uQAG/8A4WRMjNTMVM7mgVUsB2+ZQAAABABkB2wC5AsEABQBNQBsBBgZABwACAQQABQAEBAMDAgUEAQAFBAIBA0Z2LzcYAD88LzwQ/TwBLzz9PBD9PAAxMAFJaLkAAwAGSWhhsEBSWDgRN7kABv/AOFkTIzUjNTO5VUugAdtQlgAAAQAZ/6sAuQCRAAUASkAZAQYGQAcAAgEEAAUABAQDBQQBAAMCAQEDRnYvNxgAPzwvPC88AS88/TwQ/TwAMTABSWi5AAMABkloYbBAUlg4ETe5AAb/wDhZFyM1IzUzuVVLoFVQlgAAAQAZAdsAuQLBAAUATUAbAQYGQAcAAgEEAwUABAQDAQAFBAMCBQQCAQNGdi83GAA/PC88EP08AS88/TwQ/TwAMTABSWi5AAMABkloYbBAUlg4ETe5AAb/wDhZEyMVIzUzuUtVoAIrUOYAAAIAGQHbAXcCwQAFAAsAaUAtAQwMQA0ABAMEAQoJBAcCAQQFAAsGBAgHCwoFAwQFAAcGAQMACQgDAwICAQdGdi83GAA/FzwvFzwQ/Rc8AS88/TwvPP08EP08EP08ADEwAUlouQAHAAxJaGGwQFJYOBE3uQAM/8A4WQEjNTMVMwcjNTMVMwF3oFVLvqBVSwHb5lCW5lAAAAIAGQHbAXcCwQAFAAsAaUAtAQwMQA0AAgEEAAgHBAYEAwQFAAsGBAoJCQgDAwIFBAcGAQMACwoFAwQCAQlGdi83GAA/FzwvFzwQ/Rc8AS88/TwvPP08EP08EP08ADEwAUlouQAJAAxJaGGwQFJYOBE3uQAM/8A4WQEjNSM1MwcjNSM1MwF3VUugvlVLoAHbUJbmUJYAAAIAGf+rAXcAkQAFAAsAZkArAQwMQA0AAgEEAAgHBAYEAwQFAAsGBAoJCwoFAwQHBgEDAAkIAwMCAQEJRnYvNxgAPxc8Lxc8Lxc8AS88/TwvPP08EP08EP08ADEwAUlouQAJAAxJaGGwQFJYOBE3uQAM/8A4WQUjNSM1MwcjNSM1MwF3VUugvlVLoFVQluZQlgAAAAAAAAAAfAAAAHwAAAB8AAAAfAAAAPIAAAGIAAAB8gAAAlgAAAKuAAADSgAAA7YAAARiAAAFHAAABbgAAAZkAAAHGAAAB4oAAAhwAAAJJAAACZwAAAokAAAK3gAAC54AAAxiAAAM7AAADXwAAA4gAAAOrgAAD1QAAA/kAAAQPAAAEMQAABF+AAAR8AAAEqwAABNEAAAT4gAAFHoAABUcAAAV0gAAFoQAABb8AAAXhAAAGBoAABkuAAAaBgAAGqgAABtGAAAcBgAAHMoAAB1UAAAd5AAAHogAAB8WAAAfvAAAIEwAACCkAAAhLAAAIeYAACJYAAAjFAAAI6wAACRKAAAk4gAAJYQAACY6AAAm7AAAJ2QAACfsAAAoggAAKZYAACpuAAArEAAAK64AACwYAAAsggAALOgAAC1SAAAt6AAALn4AAC8QAfQAPwAAAAAA+gAAAPoAAADSABkBkAAZANIAGQDSABkA0gAZAmIAGQE2ABkCYgAZAmIAGQJiABkCYgAZAmIAGQJiABkCYgAZAmIAGQDSABkA0gAZAf4AGQLu//kClAAZAmIAGQKUABkCYgAZAmIAGQKUABkClAAZANIAGQKUABkC0AAZAmIAGQM0ABkClAAZApQAGQKUABkC+AAZApQAGQKUABkClAAZApQAGQLu//kEGv/5AvgAFAL4ABQClAAZAu7/+QKUABkCYgAZApQAGQJiABkCYgAZApQAGQKUABkA0gAZApQAGQLQABkCYgAZAzQAGQKUABkClAAZApQAGQL4ABkClAAZApQAGQKUABkClAAZAu7/+QQa//kC+AAUAvgAFAKUABkA0gAZANIAGQDSABkA0gAZAZAAGQGQABkBkAAZAAIAAAAAAAD/ewAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAUQAAAAEAAgADAAQABQAKAA8AEQATABQAFQAWABcAGAAZABoAGwAcAB0AHgAiACQAJQAmACcAKAApACoAKwAsAC0ALgAvADAAMQAyADMANAA1ADYANwA4ADkAOgA7ADwAPQBEAEUARgBHAEgASQBKAEsATABNAE4ATwBQAFEAUgBTAFQAVQBWAFcAWABZAFoAWwBcAF0AtgC3AMQBAgC0ALUAxQ1xdW90ZXJldmVyc2VkAAAAAAADAAAAAAAABMQAAQAAAAAAHAADAAEAAATEAAYEpgAAAAACTgABAAAAAAAAAAAAAAAAAAAAAQADAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAwAEAAUAAAAAAAAAAAAGAAAAAAAAAAAABwAAAAgAAAAJAAoACwAMAA0ADgAPABAAEQASABMAFAAAAAAAAAAVAAAAFgAXABgAGQAaABsAHAAdAB4AHwAgACEAIgAjACQAJQAmACcAKAApACoAKwAsAC0ALgAvAAAAAAAAAAAAAAAAADAAMQAyADMANAA1ADYANwA4ADkAOgA7ADwAPQA+AD8AQABBAEIAQwBEAEUARgBHAEgASQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEoASwBMAE0ATgBPAFAAAAAEAP4AAAAUABAAAwAEACIAJwAsAC4AOwA/AFoAeiAe//8AAAAgACcALAAuADAAPwBBAGEgGP//AAAAAAAAAAAAAAAAAAAAAAAAAAEAFAAYABgAGAAYAC4ALgBgAJL//wADAAQABQAGAAcACAAJAAoACwAMAA0ADgAPABAAEQASABMAFAAVABYAFwAYABkAGgAbABwAHQAeAB8AIAAhACIAIwAkACUAJgAnACgAKQAqACsALAAtAC4ALwAwADEAMgAzADQANQA2ADcAOAA5ADoAOwA8AD0APgA/AEAAQQBCAEMARABFAEYARwBIAEkASgBLAEwATQBOAE8AUAAAAAAAAAABAAAB7gABAFAAJAAGAbwAFgAp/10AFgAr/1sAFgAs/1gAFgAu/zEAFgBD/10AFgBF/1sAFgBG/1gAFgBI/zEAGwAW/6QAGwAw/6QAIQAf/8EAIQAp/xUAIQAr/0QAIQAs/0EAIQAu/vIAIQA5/8EAIQBD/xUAIQBF/0QAIQBG/0EAIQBI/vIAJQAW/5IAJQAf/nIAJQAw/5IAJQA5/nIAKQAW/2cAKQAf/zMAKQAw/2cAKQA5/zMAKwAW/1sAKwAf/4IAKwAw/1sAKwA5/4IALAAW/1gALAAf/4AALAAw/1gALAA5/4AALgAW/zEALgAf/v0ALgAw/zEALgA5/v0AMAAp/10AMAAr/1sAMAAs/1gAMAAu/zEAMABD/10AMABF/1sAMABG/1gAMABI/zEANQAW/6QANQAw/6QAOwAf/8EAOwAp/xUAOwAr/0QAOwAs/0EAOwAu/vIAOwA5/8EAOwBD/xUAOwBF/0QAOwBG/0EAOwBI/vIAPwAW/5IAPwAf/nIAPwAw/5IAPwA5/nIAQwAW/2cAQwAf/zMAQwAw/2cAQwA5/zMARQAW/1sARQAf/4IARQAw/1sARQA5/4IARgAW/1gARgAf/4AARgAw/1gARgA5/4AASAAW/zEASAAf/v0ASAAw/zEASAA5/v0AAAAAABAAAABUCQkFAAICAgQCAgIFAwUFBQUFBQUFAgIFBwYFBgUFBgYCBgYFBwYGBgcGBgYGBwkHBwYHBgUGBQUGBgIGBgUHBgYGBwYGBgYHCQcHBgICAgIEBAQACgsFAAMDAgQCAgIGAwYGBgYGBgYGAgIFCAcGBwYGBwcCBwcGCAcHBwgHBwcHCAsICAcIBwYHBgYHBwIHBwYIBwcHCAcHBwcICwgIBwICAgIEBAQACwwGAAMDAgQCAgIHAwcHBwcHBwcHAgIGCAcHBwcHBwcCBwgHCQcHBwgHBwcHCAwICAcIBwcHBwcHBwIHCAcJBwcHCAcHBwcIDAgIBwICAgIEBAQADA0GAAMDAwUDAwMHBAcHBwcHBwcHAwMGCQgHCAcHCAgDCAkHCggICAkICAgICQ0JCQgJCAcIBwcICAMICQcKCAgICQgICAgJDQkJCAMDAwMFBQUADQ4HAAMDAwUDAwMIBAgICAgICAgIAwMHCgkICQgICQkDCQkICwkJCQoJCQkJCg4KCgkKCQgJCAgJCQMJCQgLCQkJCgkJCQkKDgoKCQMDAwMFBQUADg8HAAQEAwYDAwMJBAkJCQkJCQkJAwMHCwkJCQkJCQkDCQoJCwkJCQsJCQkJCw8LCwkLCQkJCQkJCQMJCgkLCQkJCwkJCQkLDwsLCQMDAwMGBgYADxAIAAQEAwYDAwMJBQkJCQkJCQkJAwMICwoJCgkJCgoDCgsJDAoKCgsKCgoKCxALCwoLCgkKCQkKCgMKCwkMCgoKCwoKCgoLEAsLCgMDAwMGBgYAEBEIAAQEAwYDAwMKBQoKCgoKCgoKAwMIDAsKCwoKCwsDCwwKDQsLCwwLCwsLDBEMDAsMCwoLCgoLCwMLDAoNCwsLDAsLCwsMEQwMCwMDAwMGBgYAERIJAAQEBAcEBAQKBQoKCgoKCgoKBAQJDQsKCwoKCwsECwwKDgsLCw0LCwsLDRINDQsNCwoLCgoLCwQLDAoOCwsLDQsLCwsNEg0NCwQEBAQHBwcAEhMJAAUFBAcEBAQLBgsLCwsLCwsLBAQJDgwLDAsLDAwEDA0LDwwMDA4MDAwMDhMODgwODAsMCwsMDAQMDQsPDAwMDgwMDAwOEw4ODAQEBAQHBwcAExQKAAUFBAgEBAQMBgwMDAwMDAwMBAQKDg0MDQwMDQ0EDQ4MEA0NDQ4NDQ0NDhQODg0ODQwNDAwNDQQNDgwQDQ0NDg0NDQ0OFA4ODQQEBAQICAgAFBUKAAUFBAgEBAQMBgwMDAwMDAwMBAQKDw0MDQwMDQ0EDQ4MEA0NDQ8NDQ0NDxUPDw0PDQwNDAwNDQQNDgwQDQ0NDw0NDQ0PFQ8PDQQEBAQICAgAFRYLAAUFBAgEBAQNBw0NDQ0NDQ0NBAQLEA4NDg0NDg4EDg8NEQ4ODhAODg4OEBYQEA4QDg0ODQ0ODgQODw0RDg4OEA4ODg4QFhAQDgQEBAQICAgAFhcLAAYGBQkFBQUNBw0NDQ0NDQ0NBQULEQ8NDw0NDw8FDxANEg8PDxEPDw8PERcREQ8RDw0PDQ0PDwUPEA0SDw8PEQ8PDw8RFxERDwUFBQUJCQkAFxgMAAYGBQkFBQUOBw4ODg4ODg4OBQUMEQ8ODw4ODw8FDxEOEw8PDxEPDw8PERgREQ8RDw4PDg4PDwUPEQ4TDw8PEQ8PDw8RGBERDwUFBQUJCQkAGBkMAAYGBQoFBQUPBw8PDw8PDw8PBQUMEhAPEA8PEBAFEBEPFBAQEBIQEBAQEhkSEhASEA8QDw8QEAUQEQ8UEBAQEhAQEBASGRISEAUFBQUKCgoAAAECPgK8AAUAAgK8AooAAACPArwCigAAAcUAMgEDAAAAAAcAAAAAAAAAAAAAAwAAAAAAAAAAAAAAAE1BQ1IAIAAgIB4Cwf+rAAACwQBVAAAAAQAAAAAAAAABAACAAAAAAPoCwQAAYAACwQJ1QWxpZW4gRW5jb3VuQmQgIP////83///+QUxJQjAwAwAAAAAAAAEAAAABAACwyPKjXw889QAAA+gAAAAAsyRJsQAAAACzJEmx//n/qwQhAyAAAQADAAIAAQAAAAAAAQAAAyD+1AAABBr/+f/5BCEAAQAAAAAAAAAAAAAAAAAAAFEAAQAAAFEAJgADAAAAAAACAAgAQAAKAAAAbQDKAAEAAQ==") format("truetype");\n      font-weight: 700;\n      font-style: normal;\n    }\n  ',document.head.appendChild(A)}let hA=class extends CA{setConfig(A){if(!A||"object"!=typeof A||Array.isArray(A))throw new Error("Invalid configuration");this._config=A}getCardSize(){return 5}getGridOptions(){return{rows:5,min_rows:3,columns:12}}static getStubConfig(){return{online_miners_entity:"sensor.online_miners",offline_miners_entity:"sensor.miners_offline",fleet_power_entity:"sensor.fleet_power",fleet_energy_efficiency_entity:"sensor.fleet_energy_efficiency",btc_rate_entity:"sensor.btc_rate",bch_rate_entity:"sensor.bch_rate",ltc_rate_entity:"sensor.ltc_rate",aleo_rate_entity:"sensor.aleo_rate",solo_pool_hashrate_entity:"sensor.solo_pool_hashrate"}}static getConfigForm(){return{schema:[{name:"title",selector:{text:{}}},{name:"online_miners_entity",selector:{entity:{}}},{name:"fleet_energy_efficiency_entity",selector:{entity:{}}},{name:"fleet_power_entity",selector:{entity:{}}},{name:"offline_miners_entity",selector:{entity:{}}},{name:"btc_rate_entity",selector:{entity:{}}},{name:"bch_rate_entity",selector:{entity:{}}},{name:"ltc_rate_entity",selector:{entity:{}}},{name:"aleo_rate_entity",selector:{entity:{}}},{name:"solo_pool_hashrate_entity",selector:{entity:{}}}],computeLabel:A=>"title"===A.name?"Card Title":"online_miners_entity"===A.name?"Online Miners Entity":"fleet_energy_efficiency_entity"===A.name?"Energy Efficiency Entity":"fleet_power_entity"===A.name?"Power Entity":"offline_miners_entity"===A.name?"Miners Offline Entity":"btc_rate_entity"===A.name?"BTC Rate Entity":"bch_rate_entity"===A.name?"BCH Rate Entity":"ltc_rate_entity"===A.name?"LTC Rate Entity":"aleo_rate_entity"===A.name?"ALEO Rate Entity":"solo_pool_hashrate_entity"===A.name?"Solo Pool Hashrate Entity":void 0,computeHelper:A=>"title"===A.name?"Optional title displayed at the top of the card":"online_miners_entity"===A.name?"Select the entity to display as Online Miners":"fleet_energy_efficiency_entity"===A.name?"Select the entity to display as Energy Efficiency":"fleet_power_entity"===A.name?"Select the entity to display as Power":"offline_miners_entity"===A.name?"Select the entity to display as Miners Offline":"btc_rate_entity"===A.name?"Select the entity to display as BTC Rate":"bch_rate_entity"===A.name?"Select the entity to display as BCH Rate":"ltc_rate_entity"===A.name?"Select the entity to display as LTC Rate":"aleo_rate_entity"===A.name?"Select the entity to display as ALEO Rate":"solo_pool_hashrate_entity"===A.name?"Select the entity to display as Solo Pool Hashrate":void 0}}_getEntityState(A){if(!A)return"--";const B=this.hass?.states?.[A]?.state;return B??"n/a"}_getEntityStateWithUnit(A){const B=this._getEntityState(A);if("--"===B||"n/a"===B)return B;if(!A)return B;const Q=this.hass?.states?.[A]?.attributes?.unit_of_measurement;return"string"==typeof Q&&Q.trim().length>0?`${B} ${Q}`:B}_formatPowerState(A){const B=this._getEntityState(A);if("--"===B||"n/a"===B)return B;const Q=Number(B);if(!Number.isFinite(Q))return this._getEntityStateWithUnit(A);if(Q>=1e3){return`${(Q/1e3).toFixed(1)} kW`}return`${Math.round(Q)} W`}_formatEfficiencyState(A){const B=this._getEntityState(A);if("--"===B||"n/a"===B)return B;const Q=Number(B);return Number.isFinite(Q)?`${Q.toFixed(2)} J/TH`:this._getEntityStateWithUnit(A)}_formatHashrateState(A){const B=this._getEntityState(A);if("--"===B||"n/a"===B)return B;const Q=Number(B);if(!Number.isFinite(Q))return this._getEntityStateWithUnit(A);const t=Q.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});if(!A)return t;const e=this.hass?.states?.[A]?.attributes?.unit_of_measurement;return"string"==typeof e&&e.trim().length>0?`${t} ${e}`:t}render(){const A=this._config?.title?.trim()||"Crypto Mining Fleet";return j`
      <ha-card>
        <div class="card-shell">
          <img class="card-image" src=${cA} alt="Crypto miner card image" />
          <div class="stage-layer">
            <div class="card-title stage-item">${A}</div>

            <div class="sensor-chip stage-item hud-online">
              <ha-icon class="chip-icon chip-icon-online" icon="mdi:account-hard-hat"></ha-icon>
              <span class="chip-label">Online:</span>
              <span class="chip-value">${this._getEntityState(this._config?.online_miners_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-efficiency">
              <ha-icon class="chip-icon chip-icon-efficiency" icon="mdi:leaf"></ha-icon>
              <span class="chip-label">Efficiency</span>
              <span class="chip-value">${this._formatEfficiencyState(this._config?.fleet_energy_efficiency_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-power">
              <ha-icon class="chip-icon chip-icon-power" icon="mdi:power"></ha-icon>
              <span class="chip-label">Total</span>
              <span class="chip-value">${this._formatPowerState(this._config?.fleet_power_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-offline">
              <ha-icon class="chip-icon chip-icon-offline" icon="mdi:account-hard-hat"></ha-icon>
              <span class="chip-label">Offline:</span>
              <span class="chip-value">${this._getEntityState(this._config?.offline_miners_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-btc-rate">
              <div class="chip-rate-head">
                <span class="chip-label">BTC Hashrate</span>
              </div>
              <span class="chip-value">${this._formatHashrateState(this._config?.btc_rate_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-bch-rate">
              <div class="chip-rate-head">
                <span class="chip-label">BCH Hashrate</span>
              </div>
              <span class="chip-value">${this._formatHashrateState(this._config?.bch_rate_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-ltc-rate">
              <div class="chip-rate-head">
                <span class="chip-label">LTC Hashrate</span>
              </div>
              <span class="chip-value">${this._getEntityStateWithUnit(this._config?.ltc_rate_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-aleo-rate">
              <div class="chip-rate-head">
                <span class="chip-label">ALEO Hashrate</span>
              </div>
              <span class="chip-value">${this._getEntityStateWithUnit(this._config?.aleo_rate_entity)}</span>
            </div>

            <div class="sensor-chip stage-item hud-solo-pool-hashrate">
              <div class="chip-rate-head">
                <span class="chip-label">Solo Pool</span>
              </div>
              <span class="chip-value">${this._getEntityStateWithUnit(this._config?.solo_pool_hashrate_entity)}</span>
            </div>

            <div class="miners-title stage-item">Miners</div>
            <div class="fleet-power-title stage-item">Fleet Power</div>
          </div>
        </div>
      </ha-card>
    `}static get styles(){return w`
      :host {
        margin: 0;
        padding: 0;
        display: block;
        font-family: "AlienEncountersRegular", sans-serif;
      }

      ha-card {
        padding: 0;
        overflow: hidden;
      }

      .card-shell {
        position: relative;
        overflow: hidden;
        aspect-ratio: 16 / 18.9;
      }

      .card-image {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center 35%;
      }

      .stage-layer {
        position: absolute;
        inset: 0;
        background: transparent;
        pointer-events: none;
      }

      .stage-item {
        pointer-events: auto;
        z-index: 2;
      }

      .card-title {
        position: absolute;
        top: 9%;
        left: 50%;
        transform: translate(-50%, -50%);
        border-radius: 999px;
        padding: 6px 12px;
        color: #fff;
        font-size: 0.8rem;
        font-family: "AlienEncountersBold", sans-serif;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.7);
        background: transparent;
        border: none;
      }

      .sensor-chip {
        position: absolute;
        display: flex;
        align-items: center;
        gap: 6px;
        white-space: nowrap;
        background: transparent;
        color: #fff;
        border-radius: 8px;
        padding: 6px 8px;
        font-size: 0.927rem;
        line-height: 1;
        transform: translate(-50%, -50%);
        border: none;
      }

      .chip-label {
        opacity: 0.9;
        font-family: "AlienEncountersRegular", sans-serif;
      }

      .chip-icon {
        font-size: 1.105rem;
        --mdc-icon-size: 1.105rem;
        line-height: 1;
      }

      .chip-icon-online {
        color: #39ff14;
      }

      .chip-icon-offline {
        color: #ff2bd6;
      }

      .chip-icon-efficiency {
        color: #00f5ff;
      }

      .chip-icon-power {
        color: #f8ff00;
      }

      .hud-btc-rate,
      .hud-bch-rate,
      .hud-ltc-rate,
      .hud-aleo-rate,
      .hud-solo-pool-hashrate {
        flex-direction: column;
        align-items: center;
        gap: 4px;
        width: 20%;
        padding: 0;
        font-size: 0.751rem;
        line-height: 1.15;
        text-align: center;
      }

      .chip-rate-head {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
      }

      .hud-btc-rate .chip-value,
      .hud-bch-rate .chip-value,
      .hud-ltc-rate .chip-value,
      .hud-aleo-rate .chip-value,
      .hud-solo-pool-hashrate .chip-value {
        margin-left: 0;
        width: 100%;
        text-align: center;
      }

      .hud-btc-rate .chip-label {
        color: #ff8c00;
      }

      .hud-bch-rate .chip-label {
        color: #39ff14;
      }

      .hud-ltc-rate .chip-label {
        color: #00f5ff;
      }

      .hud-aleo-rate .chip-label {
        color: #f8ff00;
      }

      .fleet-power-title {
        position: absolute;
        top: 59%;
        left: 71%;
        transform: translate(-50%, -50%);
        color: #fff;
        font-size: 1.151rem;
        font-family: "AlienEncountersBold", sans-serif;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.7);
        background: transparent;
        border: none;
        white-space: nowrap;
      }

      .miners-title {
        position: absolute;
        top: 59%;
        left: 30%;
        transform: translate(-50%, -50%);
        color: #fff;
        font-size: 1.151rem;
        font-family: "AlienEncountersBold", sans-serif;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.7);
        background: transparent;
        border: none;
        white-space: nowrap;
      }

      .chip-value {
        margin-left: 2px;
        text-align: left;
        font-family: "AlienEncountersBold", sans-serif;
        font-weight: 700;
      }

      .hud-online {
        top: 64%;
        left: 29%;
      }

      .hud-efficiency {
        top: 64%;
        left: 70%;
      }

      .hud-power {
        top: 70%;
        left: 70%;
      }

      .hud-offline {
        top: 70%;
        left: 29%;
      }

      .hud-btc-rate {
        top: 42.5%;
        left: 23%;
      }

      .hud-bch-rate {
        top: 48%;
        left: 23%;
      }

      .hud-ltc-rate {
        top: 42.5%;
        left: 77%;
      }

      .hud-aleo-rate {
        top: 48%;
        left: 77%;
      }

      .hud-solo-pool-hashrate {
        top: 45.25%;
        left: 50%;
      }

      @media (max-width: 640px) {
        .card-title {
          font-size: 0.7rem;
          padding: 5px 10px;
        }

        .sensor-chip {
          font-size: 0.8rem;
          gap: 4px;
          padding: 4px 6px;
        }

        .chip-icon {
          font-size: 0.96rem;
          --mdc-icon-size: 0.96rem;
        }

        .miners-title,
        .fleet-power-title {
          font-size: 1.03rem;
          top: 58.5%;
        }

        .hud-online {
          top: 64.5%;
          left: 30%;
        }

        .hud-offline {
          top: 70.5%;
          left: 30%;
        }

        .hud-efficiency {
          top: 64.5%;
          left: 69%;
        }

        .hud-power {
          top: 70.5%;
          left: 69%;
        }

        .hud-efficiency .chip-value,
        .hud-power .chip-value {
          font-size: 0.76rem;
        }

        .hud-btc-rate,
        .hud-bch-rate,
        .hud-ltc-rate,
        .hud-aleo-rate,
        .hud-solo-pool-hashrate {
          font-size: 0.69rem;
          width: 24%;
          line-height: 1.1;
          gap: 3px;
        }

        .hud-solo-pool-hashrate {
          width: 18%;
          font-size: 0.71rem;
          top: 45.5%;
        }
      }

      @media (max-width: 400px) {
        .card-title {
          font-size: 0.6rem;
          padding: 4px 8px;
        }

        .sensor-chip {
          font-size: 0.7rem;
          gap: 3px;
          padding: 3px 5px;
        }

        .chip-icon {
          font-size: 0.85rem;
          --mdc-icon-size: 0.85rem;
        }

        .miners-title,
        .fleet-power-title {
          font-size: 0.9rem;
          top: 58%;
        }

        .hud-online {
          top: 65%;
          left: 31%;
        }

        .hud-offline {
          top: 71%;
          left: 31%;
        }

        .hud-efficiency {
          top: 65%;
          left: 68%;
        }

        .hud-power {
          top: 71%;
          left: 68%;
        }

        .hud-efficiency .chip-value,
        .hud-power .chip-value {
          font-size: 0.65rem;
        }

        .hud-btc-rate,
        .hud-bch-rate,
        .hud-ltc-rate,
        .hud-aleo-rate,
        .hud-solo-pool-hashrate {
          font-size: 0.6rem;
          width: 22%;
          line-height: 1;
          gap: 2px;
        }

        .hud-solo-pool-hashrate {
          width: 16%;
          font-size: 0.62rem;
          top: 45.25%;
        }
      }
    `}};rA([function(A){return(B,Q)=>"object"==typeof Q?DA(A,B,Q):((A,B,Q)=>{const t=B.hasOwnProperty(Q);return B.constructor.createProperty(Q,A),t?Object.getOwnPropertyDescriptor(B,Q):void 0})(A,B,Q)}({attribute:!1})],hA.prototype,"hass",void 0),hA=rA([(A=>(B,Q)=>{void 0!==Q?Q.addInitializer(()=>{customElements.define(A,B)}):customElements.define(A,B)})("crypto-miner-card")],hA),window.customCards=window.customCards||[],window.customCards.push({type:"crypto-miner-card",name:"Crypto Miner Card",description:"Custom card for monitoring crypto miner fleet",preview:!0,documentationURL:"https://developers.home-assistant.io/docs/frontend/custom-ui/custom-card/"});export{hA as CryptoMinerCard};